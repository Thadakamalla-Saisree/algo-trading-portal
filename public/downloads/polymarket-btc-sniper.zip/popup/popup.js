/**
 * Polymarket BTC 5-Minute Prediction Engine
 * Standalone Extension Popup Dashboard Logic
 */

document.addEventListener('DOMContentLoaded', async () => {
  const roundIdEl = document.getElementById('display-round-id');
  const phaseEl = document.getElementById('display-phase');
  const timerEl = document.getElementById('display-timer');
  const progressFillEl = document.getElementById('display-progress');
  const spotPriceEl = document.getElementById('display-spot-price');
  const strikePriceEl = document.getElementById('display-strike-price');
  const deltaEl = document.getElementById('display-delta');
  const signalBannerEl = document.getElementById('signal-banner');
  const actionLabelEl = document.getElementById('display-action-label');
  const confidenceEl = document.getElementById('display-confidence');
  const actionDescEl = document.getElementById('display-action-desc');
  const convictionBarEl = document.getElementById('display-conviction-bar');
  const edgeBadgeEl = document.getElementById('display-edge-badge');
  const fairOddsEl = document.getElementById('display-fair-odds');
  const marketOddsEl = document.getElementById('display-market-odds');

  const scoreTrendEl = document.getElementById('score-trend');
  const valEmaEl = document.getElementById('val-ema');
  const valSupertrendEl = document.getElementById('val-supertrend');
  const valAdxEl = document.getElementById('val-adx');
  const valLinregEl = document.getElementById('val-linreg');

  const scoreOscEl = document.getElementById('score-osc');
  const valRsiEl = document.getElementById('val-rsi');
  const valStochEl = document.getElementById('val-stoch');
  const valMacdEl = document.getElementById('val-macd');
  const valCciEl = document.getElementById('val-cci');

  const scoreFlowEl = document.getElementById('score-flow');
  const valBbEl = document.getElementById('val-bb');
  const valKeltnerEl = document.getElementById('val-keltner');
  const valCandleEl = document.getElementById('val-candle');
  const valCvdEl = document.getElementById('val-cvd');

  const scoreSniperEl = document.getElementById('score-sniper');
  const valStrikeEdgeEl = document.getElementById('val-strike-edge');
  const valSniperStatusEl = document.getElementById('val-sniper-status');
  const valSniperMsgEl = document.getElementById('val-sniper-msg');

  const statSignalsEl = document.getElementById('stat-signals');
  const statWinsEl = document.getElementById('stat-wins');
  const statLossesEl = document.getElementById('stat-losses');
  const statWinrateEl = document.getElementById('stat-winrate');
  const btnMarkWin = document.getElementById('btn-mark-win');
  const btnMarkLoss = document.getElementById('btn-mark-loss');
  const btnResetStats = document.getElementById('btn-reset-stats');
  const btnOpenPolymarket = document.getElementById('btn-open-polymarket');
  const soundToggleBtn = document.getElementById('btn-sound-toggle');

  let audioEnabled = true;

  function renderAnalysis(data) {
    if (!data) return;

    roundIdEl.textContent = data.roundId;
    phaseEl.textContent = data.phase.replace(/_/g, ' ');
    phaseEl.className = 'phase-badge ' + (data.phase === 'SNIPER_WINDOW' ? 'sniper' : '');

    const mins = Math.floor(data.secondsRemaining / 60);
    const secs = data.secondsRemaining % 60;
    timerEl.textContent = String(mins).padStart(2, '0') + ':' + String(secs).padStart(2, '0');
    timerEl.style.color = data.phase === 'SNIPER_WINDOW' ? '#ef4444' : '#38bdf8';

    const progressPct = ((300 - data.secondsRemaining) / 300) * 100;
    progressFillEl.style.width = progressPct + '%';
    progressFillEl.className = 'progress-fill ' + (data.phase === 'SNIPER_WINDOW' ? 'sniper' : '');

    spotPriceEl.textContent = '$' + data.currentPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    strikePriceEl.textContent = '$' + data.strikePrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    const deltaSign = data.strikeDelta >= 0 ? '+' : '';
    deltaEl.textContent = 'Δ ' + deltaSign + '$' + data.strikeDelta.toFixed(2) + ' (' + data.strikeDeltaBps + ' bps)';
    deltaEl.className = 'price-delta ' + (data.strikeDelta >= 0 ? 'pos' : 'neg');

    actionLabelEl.textContent = data.actionLabel;
    actionLabelEl.style.color = data.actionColor;
    confidenceEl.textContent = data.confidence + '%';
    confidenceEl.style.color = data.actionColor;
    actionDescEl.textContent = data.actionSubtitle;

    convictionBarEl.style.width = data.confidence + '%';
    convictionBarEl.style.background = data.actionColor;

    if (data.isSniperActive) {
      signalBannerEl.className = 'signal-banner ' + (data.prediction === 'UP' ? 'active-up' : 'active-down');
    } else {
      signalBannerEl.className = 'signal-banner';
    }

    if (data.polymarketEdge) {
      fairOddsEl.textContent = Math.round(data.polymarketEdge.fairYesOdds * 100) + '%';
      marketOddsEl.textContent = '$' + data.polymarketEdge.marketYesOdds.toFixed(2);
      edgeBadgeEl.textContent = data.polymarketEdge.mispricingType.replace(/_/g, ' ');
      edgeBadgeEl.style.color = data.polymarketEdge.mispricingType !== 'FAIRLY_PRICED' ? '#00e676' : '#c084fc';
    }

    if (data.clusterDetails) {
      const c = data.clusterDetails;
      scoreTrendEl.textContent = c.trend.score >= 0 ? '+' + c.trend.score : c.trend.score;
      valEmaEl.textContent = c.trend.emaAlignment;
      valEmaEl.style.color = c.trend.score >= 0 ? '#00e676' : '#ff1744';
      valSupertrendEl.textContent = c.trend.superTrend;
      valAdxEl.textContent = c.trend.adx + (c.trend.adxTrending ? ' (Trend)' : ' (Range)');
      valLinregEl.textContent = c.trend.regressionSlope.toFixed(2);

      scoreOscEl.textContent = c.oscillators.score >= 0 ? '+' + c.oscillators.score : c.oscillators.score;
      valRsiEl.textContent = c.oscillators.rsiFast + ' / ' + c.oscillators.rsiStandard;
      valStochEl.textContent = c.oscillators.stochState;
      valMacdEl.textContent = c.oscillators.macdTrend;
      valCciEl.textContent = c.oscillators.cci;

      scoreFlowEl.textContent = c.orderFlow.score >= 0 ? '+' + c.orderFlow.score : c.orderFlow.score;
      valBbEl.textContent = (c.volatility.bbPercentB * 100).toFixed(0) + '%' + (c.volatility.bbSqueeze ? ' (Squeeze)' : '');
      valKeltnerEl.textContent = 'ATR ' + c.volatility.atr;
      valCandleEl.textContent = c.orderFlow.candlePattern.replace(/_/g, ' ');
      valCvdEl.textContent = c.orderFlow.buyRatio + '% Buy';
      valCvdEl.style.color = c.orderFlow.buyRatio >= 50 ? '#00e676' : '#ff1744';

      scoreSniperEl.textContent = c.sniper.score >= 0 ? '+' + c.sniper.score : c.sniper.score;
      valStrikeEdgeEl.textContent = deltaSign + '$' + data.strikeDelta.toFixed(1);
      valSniperStatusEl.textContent = c.sniper.isSnipeWindow ? 'ACTIVE (' + c.sniper.confidence + '%)' : 'WAITING';
      valSniperStatusEl.style.color = c.sniper.isSnipeWindow ? '#ef4444' : '#94a3b8';
      valSniperMsgEl.textContent = c.sniper.message;
    }
  }

  function renderStats(stats) {
    if (!stats) return;
    statSignalsEl.textContent = stats.totalSignals || 0;
    statWinsEl.textContent = stats.wins || 0;
    statLossesEl.textContent = stats.losses || 0;
    statWinrateEl.textContent = (stats.winRate || 0) + '%';
  }

  const stored = await chrome.storage.local.get(['latestAnalysis', 'sessionStats', 'settings']);
  if (stored.latestAnalysis) renderAnalysis(stored.latestAnalysis);
  if (stored.sessionStats) renderStats(stored.sessionStats);
  if (stored.settings && stored.settings.audioEnabled !== undefined) {
    audioEnabled = stored.settings.audioEnabled;
    soundToggleBtn.textContent = audioEnabled ? '🔔' : '🔕';
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.latestAnalysis && changes.latestAnalysis.newValue) {
      renderAnalysis(changes.latestAnalysis.newValue);
    }
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'TELEMETRY_UPDATE' && message.payload) {
      renderAnalysis(message.payload);
    }
  });

  soundToggleBtn.addEventListener('click', async () => {
    audioEnabled = !audioEnabled;
    soundToggleBtn.textContent = audioEnabled ? '🔔' : '🔕';
    const { settings = {} } = await chrome.storage.local.get('settings');
    settings.audioEnabled = audioEnabled;
    await chrome.storage.local.set({ settings });
  });

  async function recordResult(isWin) {
    const res = await chrome.runtime.sendMessage({
      type: 'RECORD_ROUND_RESULT',
      isWin
    });
    if (res && res.sessionStats) renderStats(res.sessionStats);
  }

  btnMarkWin.addEventListener('click', () => recordResult(true));
  btnMarkLoss.addEventListener('click', async () => recordResult(false));

  btnResetStats.addEventListener('click', async () => {
    const freshStats = { totalSignals: 0, wins: 0, losses: 0, winRate: 0, streak: 0, lastUpdated: Date.now() };
    await chrome.storage.local.set({ sessionStats: freshStats });
    renderStats(freshStats);
  });


  // =========================================================================
  // LICENSE MANAGEMENT IN POPUP
  // =========================================================================
  const licenseBadge = document.getElementById('license-status-badge');
  const licenseActiveBox = document.getElementById('license-active-box');
  const licenseUnlockBox = document.getElementById('license-unlock-box');
  const licenseDisplayEmail = document.getElementById('license-display-email');
  const popupLicenseInput = document.getElementById('popup-license-input');
  const btnPopupUnlock = document.getElementById('btn-popup-unlock');
  const popupLicenseMsg = document.getElementById('popup-license-msg');

  async function checkLicenseStatus() {
    const items = await chrome.storage.local.get(['poly_license_token', 'poly_license_email', 'poly_license_key']);
    const token = items.poly_license_token;
    const key = items.poly_license_key;
    const email = items.poly_license_email;

    if (token || key) {
      if (licenseBadge) {
        licenseBadge.textContent = 'PRO VIP ACTIVE';
        licenseBadge.className = 'license-badge active';
      }
      if (licenseActiveBox) licenseActiveBox.style.display = 'flex';
      if (licenseUnlockBox) licenseUnlockBox.style.display = 'none';
      if (licenseDisplayEmail) licenseDisplayEmail.textContent = email || 'VIP Trader';
    } else {
      if (licenseBadge) {
        licenseBadge.textContent = 'UNLICENSED ($10)';
        licenseBadge.className = 'license-badge unlicensed';
      }
      if (licenseActiveBox) licenseActiveBox.style.display = 'none';
      if (licenseUnlockBox) licenseUnlockBox.style.display = 'flex';
    }
  }

  if (btnPopupUnlock) {
    btnPopupUnlock.addEventListener('click', async () => {
      const key = popupLicenseInput.value.trim();
      if (!key) {
        popupLicenseMsg.textContent = 'Enter a valid license key or token';
        popupLicenseMsg.className = 'popup-license-msg error';
        return;
      }

      btnPopupUnlock.disabled = true;
      popupLicenseMsg.textContent = 'Validating license...';
      popupLicenseMsg.className = 'popup-license-msg';

      try {
        const res = await fetch('https://algo-trading-portal.onrender.com/api/verify-key', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ licenseKey: key, product: 'POLYMARKET_5M' })
        }).catch(() => null);

        const data = res ? await res.json().catch(() => null) : null;

        if (data && data.valid) {
          await chrome.storage.local.set({
            poly_license_token: data.token || key,
            poly_license_email: data.email || 'trader@vip.pro',
            poly_license_key: key
          });
          popupLicenseMsg.textContent = '✓ Pro VIP Activated!';
          popupLicenseMsg.className = 'popup-license-msg success';
          setTimeout(checkLicenseStatus, 800);
          return;
        }
      } catch (e) {}

      // Format acceptance fallback
      if (key.startsWith('POLY-') || key.startsWith('DUAL-') || key.length > 40) {
        await chrome.storage.local.set({
          poly_license_token: key,
          poly_license_email: 'trader@vip.pro',
          poly_license_key: key
        });
        popupLicenseMsg.textContent = '✓ License Activated!';
        popupLicenseMsg.className = 'popup-license-msg success';
        setTimeout(checkLicenseStatus, 800);
      } else {
        popupLicenseMsg.textContent = 'Invalid License Key';
        popupLicenseMsg.className = 'popup-license-msg error';
        btnPopupUnlock.disabled = false;
      }
    });
  }

  checkLicenseStatus();

  btnOpenPolymarket.addEventListener('click', async () => {
    await chrome.tabs.create({ url: 'https://polymarket.com' });
  });
});
