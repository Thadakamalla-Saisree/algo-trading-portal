﻿# -*- coding: utf-8 -*-
import json

print("Starting clean build...")
