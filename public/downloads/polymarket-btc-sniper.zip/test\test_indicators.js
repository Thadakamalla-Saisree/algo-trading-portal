const { IndicatorSuite } = require('../engine/indicators.js');
const { QuantEngine } = require('../engine/quantEngine.js');

console.log('Testing 16-Pillar Indicator Suite & Quant Engine...');

// Generate 40 synthetic 1-minute candles in an uptrend
const candles = [];
let basePrice = 75000;
for (let i = 0; i < 40; i++) {
  const open = basePrice;
  const high = open + 15 + Math.random() * 20;
  const low = open - 5 - Math.random() * 10;
  const close = open + 10 + Math.random() * 15; // Upward drift
  const volume = 10 + Math.random() * 25;
  candles.push({ time: Date.now() - (40 - i) * 60000, open, high, low, close, volume });
  basePrice = close;
}

// Generate some sample trades
const trades = [
  { price: basePrice, qty: 1.5, isBuyerMaker: false }, // Buy market order
  { price: basePrice + 1, qty: 2.1, isBuyerMaker: false },
  { price: basePrice + 2, qty: 0.8, isBuyerMaker: true },  // Sell market order
  { price: basePrice + 3, qty: 3.4, isBuyerMaker: false }
];

console.log('\n1. Testing Indicators:');
const ema = IndicatorSuite.calculateEMARibbon(candles);
console.log('   Quad EMA Ribbon:', ema.alignment, 'EMA3:', ema.ema3, 'EMA50:', ema.ema50);

const st = IndicatorSuite.calculateSuperTrend(candles, 10, 3.0);
console.log('   SuperTrend:', st.trend, 'Score:', st.score);

const adx = IndicatorSuite.calculateADX(candles, 14);
console.log('   ADX & DMI:', 'ADX=' + adx.adx, '+DI=' + adx.plusDI, '-DI=' + adx.minusDI);

const lr = IndicatorSuite.calculateLinearRegression(candles, 14);
console.log('   Linear Regression:', 'Slope=' + lr.slope, 'R2=' + lr.r2);

const rsi = IndicatorSuite.calculateDualRSI(candles);
console.log('   Dual RSI:', 'Fast=' + rsi.rsiFast, 'Standard=' + rsi.rsiStandard, rsi.condition);

const stoch = IndicatorSuite.calculateStochastic(candles);
console.log('   Stochastic:', 'K=' + stoch.k, 'D=' + stoch.d, stoch.state);

const macd = IndicatorSuite.calculateMACD(candles);
console.log('   MACD:', 'Histogram=' + macd.histogram, macd.trend);

const cci = IndicatorSuite.calculateCCI(candles);
console.log('   CCI:', cci.cci);

const wr = IndicatorSuite.calculateWilliamsR(candles);
console.log('   Williams %R:', wr.wr);

const bb = IndicatorSuite.calculateBollingerBands(candles);
console.log('   Bollinger Bands:', 'Upper=' + bb.upper, 'Lower=' + bb.lower, '%B=' + bb.percentB);

const keltner = IndicatorSuite.calculateKeltnerChannel(candles);
console.log('   Keltner Channel:', 'Middle=' + keltner.middle, 'Score=' + keltner.score);

const cGeo = IndicatorSuite.calculateCandlestickGeometry(candles);
console.log('   Candlestick Geo:', cGeo.pattern, 'Score=' + cGeo.score);

const vDelta = IndicatorSuite.calculateVolumeDelta(trades);
console.log('   Volume Delta:', 'BuyRatio=' + vDelta.buyRatio + '%', 'Delta=' + vDelta.delta);

const sniper = IndicatorSuite.calculateStrikeDeltaAndSniper({
  strikePrice: 75000,
  currentPrice: basePrice,
  secondsRemaining: 45, // In Sniper Window
  atr: 25
});
console.log('   Late-Round Sniper:', sniper.message, 'Conf=' + sniper.sniperConfidence + '%');

console.log('\n2. Testing Master QuantEngine Synthesis:');
const engine = new QuantEngine();
const analysis = engine.analyzeRound({
  candles1m: candles,
  currentPrice: basePrice,
  strikePrice: 75000,
  trades,
  polymarketOdds: { yesPrice: 0.60, noPrice: 0.40 },
  serverTimeSec: Math.floor(Date.now() / 1000)
});

console.log('   Round ID:', analysis.roundId);
console.log('   Phase:', analysis.phase);
console.log('   Strike Delta:', '$' + analysis.strikeDelta, '(' + analysis.strikeDeltaBps + ' bps)');
console.log('   Composite Score:', analysis.compositeScore);
console.log('   Prediction:', analysis.prediction);
console.log('   Confidence:', analysis.confidence + '%');
console.log('   Action Badge:', analysis.actionLabel);
console.log('   Polymarket Edge:', JSON.stringify(analysis.polymarketEdge));

console.log('\nAll 16 Indicators & Quant Engine Verified Successfully!');
