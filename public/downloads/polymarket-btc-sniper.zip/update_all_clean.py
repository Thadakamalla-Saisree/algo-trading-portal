﻿import os

print("Writing clean content.js...")
