/**
 * Polymarket BTC 5-Minute Prediction Engine
 * On-Page Floating HUD Content Script
 * 
 * - Full lifecycle protection against "Extension context invalidated"
 * - Synchronizes spot price, "Price To Beat", and countdown directly with Polymarket DOM
 * - Real-time low-latency trade stream via Chrome Port
 * - 16-pillar quantitative confluence HUD
 */

(function () {
  'use strict';

  // --- 1. EXTENSION CONTEXT SAFETY & ORPHAN CLEANUP ---
  function isContextValid() {
    try {
      return typeof chrome !== 'undefined' && !!chrome.runtime && !!chrome.runtime.id;
    } catch (e) {
      return false;
    }
  }

  if (!isContextValid()) return;

  // Clean up any previously injected instance or orphaned HUD on this tab
  if (window.__POLY_SNIPER_CLEANUP__) {
    try { window.__POLY_SNIPER_CLEANUP__(); } catch (e) {}
  }
  const existingHud = document.getElementById('poly-sniper-hud');
  if (existingHud) existingHud.remove();

  let isAlive = true;
  let scrapeInterval = null;
  let clockInterval = null;
  let flashTimer = null;
  let domObserver = null;
  let port = null;

  function cleanup() {
    isAlive = false;
    try { clearInterval(scrapeInterval); } catch (e) {}
    try { clearInterval(clockInterval); } catch (e) {}
    try { clearTimeout(flashTimer); } catch (e) {}
    try { if (domObserver) domObserver.disconnect(); } catch (e) {}
    try { if (port) port.disconnect(); } catch (e) {}
    const el = document.getElementById('poly-sniper-hud');
    if (el) el.remove();
    window.__POLY_SNIPER_CLEANUP__ = null;
  }

  window.__POLY_SNIPER_CLEANUP__ = cleanup;

  function safeStorageSet(data) {
    if (!isContextValid() || !isAlive) return;
    try {
      chrome.storage.local.set(data).catch(() => {});
    } catch (e) {}
  }

  // --- 2. AUDIO SYNTHESIZER ---
  let audioContext = null;
  let audioEnabled = true;
  let lastPlayedRoundId = null;

  function playChime(freq, type) {
    freq = freq || 880;
    type = type || 'sine';
    try {
      if (!audioEnabled || !isAlive) return;
      if (!audioContext) {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
      }
      if (audioContext.state === 'suspended') audioContext.resume();
      const osc = audioContext.createOscillator();
      const gain = audioContext.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, audioContext.currentTime);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.5, audioContext.currentTime + 0.18);
      gain.gain.setValueAtTime(0.18, audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(audioContext.destination);
      osc.start();
      osc.stop(audioContext.currentTime + 0.35);
    } catch (e) {}
  }


  // ==========================================================================
  // POLYMARKET BTC 5M SNIPER PRO - CRYPTOGRAPHIC LICENSING & PAYWALL GATEWAY
  // ==========================================================================

  const LICENSE_CONFIG = {
    API_LOCAL: 'http://localhost:3000/api',
    API_REMOTE: 'https://algo-trading-portal.onrender.com/api',
    TRC20_ADDRESS: 'TLXS78k5X6cB9zQHzDQeh4NtTddmj7Z8L7',
    BEP20_ADDRESS: '0x86c304c8015c1a51a520e66295ad75f85aa08b60',
    PORTAL_URL: 'https://algo-trading-portal.onrender.com'
  };

  async function apiPost(endpoint, body) {
    const urls = [LICENSE_CONFIG.API_LOCAL + endpoint, LICENSE_CONFIG.API_REMOTE + endpoint];
    let lastError = null;
    for (const url of urls) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 4000);
        const res = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        const data = await res.json();
        return { ok: res.ok, status: res.status, data };
      } catch (err) {
        lastError = err;
      }
    }
    throw lastError || new Error('Network request failed');
  }

  function renderPaywallModal(onUnlocked) {
    if (document.getElementById('poly-paywall-overlay')) return;

    let selectedNetwork = 'TRC20';
    const trcAddr = LICENSE_CONFIG.TRC20_ADDRESS;
    const bepAddr = LICENSE_CONFIG.BEP20_ADDRESS;

    const overlay = document.createElement('div');
    overlay.id = 'poly-paywall-overlay';
    overlay.className = 'poly-paywall-overlay';
    overlay.innerHTML = `
      <div class="poly-paywall-card">
        <div class="poly-paywall-header">
          <span class="poly-paywall-badge">⚡ Lifetime Pro Access • $10 USDT</span>
          <h2 class="poly-paywall-title">POLYMARKET BTC 5M SNIPER</h2>
          <p class="poly-paywall-subtitle">Institutional 16-Pillar Quantitative Binary HUD</p>
        </div>

        <div class="poly-paywall-tabs">
          <button class="poly-paywall-tab-btn active" id="poly-tab-pay">💳 Crypto ($10)</button>
          <button class="poly-paywall-tab-btn" id="poly-tab-key">🔑 License Key</button>
          <button class="poly-paywall-tab-btn" id="poly-tab-login">👤 Sign In</button>
        </div>

        <!-- TAB 1: PAY WITH CRYPTO -->
        <div id="poly-view-pay">
          <div class="poly-field-group">
            <label class="poly-field-label">Your Email</label>
            <input type="email" id="poly-reg-email" class="poly-input" placeholder="trader@example.com" />
          </div>

          <div class="poly-field-group">
            <label class="poly-field-label">Account Password (for future logins)</label>
            <input type="password" id="poly-reg-password" class="poly-input" placeholder="Create password" />
          </div>

          <div class="poly-field-group">
            <label class="poly-field-label">Select USDT Network</label>
            <div class="poly-net-selector">
              <button class="poly-net-btn active" id="poly-net-trc20" type="button">USDT (TRC-20 Tron)</button>
              <button class="poly-net-btn" id="poly-net-bep20" type="button">USDT (BEP-20 BSC BNB)</button>
            </div>
          </div>

          <div class="poly-address-box">
            <span class="poly-field-label">Binance Deposit Address:</span>
            <span class="poly-address-text" id="poly-deposit-addr">${trcAddr}</span>
            <button class="poly-btn-copy" id="poly-copy-addr-btn" type="button">📋 Copy Address</button>
            <div class="poly-qr-wrap">
              <img id="poly-qr-img" src="https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${trcAddr}" alt="USDT QR Code" />
            </div>
          </div>

          <div class="poly-paywall-notice">
            ⚡ Send exactly <strong>10 USDT</strong> to the address above. Once sent, paste your Transaction Hash (TxID) below:
          </div>

          <div class="poly-field-group">
            <label class="poly-field-label">Transaction Hash (TxID)</label>
            <input type="text" id="poly-txid-input" class="poly-input" placeholder="Paste 64-char TxID here..." />
          </div>

          <button class="poly-btn-primary" id="poly-submit-pay-btn" type="button">
            ⚡ Verify On-Chain & Unlock Pro HUD
          </button>
        </div>

        <!-- TAB 2: ENTER LICENSE KEY -->
        <div id="poly-view-key" style="display: none;">
          <div class="poly-paywall-notice">
            Bought via the official website portal? Paste your Lifetime License Key or Token below:
          </div>

          <div class="poly-field-group">
            <label class="poly-field-label">Registered Email</label>
            <input type="email" id="poly-key-email" class="poly-input" placeholder="trader@example.com" />
          </div>

          <div class="poly-field-group">
            <label class="poly-field-label">License Key or Token</label>
            <input type="text" id="poly-key-input" class="poly-input" placeholder="POLY-LIFETIME-... or DUAL-VIP-..." />
          </div>

          <button class="poly-btn-primary" id="poly-submit-key-btn" type="button">
            🚀 Activate License Key
          </button>
        </div>

        <!-- TAB 3: SIGN IN -->
        <div id="poly-view-login" style="display: none;">
          <div class="poly-field-group">
            <label class="poly-field-label">Your Email</label>
            <input type="email" id="poly-login-email" class="poly-input" placeholder="trader@example.com" />
          </div>

          <div class="poly-field-group">
            <label class="poly-field-label">Password</label>
            <input type="password" id="poly-login-password" class="poly-input" placeholder="Enter your password" />
          </div>

          <button class="poly-btn-primary" id="poly-submit-login-btn" type="button">
            👤 Sign In & Unlock Pro HUD
          </button>
        </div>

        <a class="poly-btn-secondary" href="https://algo-trading-portal.onrender.com" target="_blank">
          🌐 Visit Official Web Store ($10 / $18 Dual Bundle)
        </a>

        <div class="poly-paywall-status" id="poly-paywall-status"></div>

        <div class="poly-paywall-footer">
          Direct Binance Crypto Deposit • 100% Automated On-Chain Verification
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    const tabPay = document.getElementById('poly-tab-pay');
    const tabKey = document.getElementById('poly-tab-key');
    const tabLogin = document.getElementById('poly-tab-login');
    const viewPay = document.getElementById('poly-view-pay');
    const viewKey = document.getElementById('poly-view-key');
    const viewLogin = document.getElementById('poly-view-login');
    const btnTrc20 = document.getElementById('poly-net-trc20');
    const btnBep20 = document.getElementById('poly-net-bep20');
    const addrDisplay = document.getElementById('poly-deposit-addr');
    const qrImg = document.getElementById('poly-qr-img');
    const copyBtn = document.getElementById('poly-copy-addr-btn');
    const payBtn = document.getElementById('poly-submit-pay-btn');
    const keyBtn = document.getElementById('poly-submit-key-btn');
    const loginBtn = document.getElementById('poly-submit-login-btn');
    const statusEl = document.getElementById('poly-paywall-status');

    function showStatus(msg, type) {
      if (!statusEl) return;
      statusEl.textContent = msg;
      statusEl.className = 'poly-paywall-status ' + (type || 'info');
    }

    tabPay.addEventListener('click', () => {
      tabPay.classList.add('active');
      tabKey.classList.remove('active');
      tabLogin.classList.remove('active');
      viewPay.style.display = 'block';
      viewKey.style.display = 'none';
      viewLogin.style.display = 'none';
      showStatus('', '');
    });

    tabKey.addEventListener('click', () => {
      tabKey.classList.add('active');
      tabPay.classList.remove('active');
      tabLogin.classList.remove('active');
      viewPay.style.display = 'none';
      viewKey.style.display = 'block';
      viewLogin.style.display = 'none';
      showStatus('', '');
    });

    tabLogin.addEventListener('click', () => {
      tabLogin.classList.add('active');
      tabPay.classList.remove('active');
      tabKey.classList.remove('active');
      viewPay.style.display = 'none';
      viewKey.style.display = 'none';
      viewLogin.style.display = 'block';
      showStatus('', '');
    });

    btnTrc20.addEventListener('click', () => {
      selectedNetwork = 'TRC20';
      btnTrc20.classList.add('active');
      btnBep20.classList.remove('active');
      addrDisplay.textContent = trcAddr;
      qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${trcAddr}`;
    });

    btnBep20.addEventListener('click', () => {
      selectedNetwork = 'BEP20';
      btnBep20.classList.add('active');
      btnTrc20.classList.remove('active');
      addrDisplay.textContent = bepAddr;
      qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${bepAddr}`;
    });

    copyBtn.addEventListener('click', () => {
      const activeAddr = selectedNetwork === 'TRC20' ? trcAddr : bepAddr;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(activeAddr).then(() => {
          copyBtn.textContent = '✓ Copied!';
          setTimeout(() => { copyBtn.textContent = '📋 Copy Address'; }, 2000);
        }).catch(() => {
          copyBtn.textContent = '✓ Copied!';
        });
      } else {
        copyBtn.textContent = '✓ Copied!';
      }
    });

    payBtn.addEventListener('click', async () => {
      const email = document.getElementById('poly-reg-email').value.trim();
      const password = document.getElementById('poly-reg-password').value.trim();
      const txid = document.getElementById('poly-txid-input').value.trim();

      if (!email || !email.includes('@')) {
        showStatus('Please enter a valid email address.', 'error');
        return;
      }
      if (!password || password.length < 4) {
        showStatus('Please enter a password (min 4 characters).', 'error');
        return;
      }
      if (!txid || txid.length < 16) {
        showStatus('Please enter a valid transaction hash (TxID).', 'error');
        return;
      }

      payBtn.disabled = true;
      showStatus('🔍 Verifying 10 USDT on ' + selectedNetwork + ' blockchain...', 'info');

      try {
        try {
          await apiPost('/register', { email, password });
        } catch (e) {}

        const res = await apiPost('/submit-payment', {
          email,
          network: selectedNetwork,
          txid,
          product: 'POLYMARKET_5M'
        });

        if (res.ok && res.data.success && res.data.licenseToken) {
          showStatus('⚡ Payment Verified On-Chain! Unlocking Pro HUD...', 'success');
          chrome.storage.local.set({
            poly_license_token: res.data.licenseToken,
            poly_license_email: email,
            poly_license_key: res.data.licenseKey || ('POLY-LIFETIME-' + txid.slice(0, 8).toUpperCase())
          }, () => {
            setTimeout(() => {
              overlay.remove();
              onUnlocked();
            }, 1000);
          });
        } else {
          showStatus(res.data.error || 'Verification failed. Please check TxID.', 'error');
          payBtn.disabled = false;
        }
      } catch (err) {
        showStatus('Connection failed. Make sure backend is running or check internet.', 'error');
        payBtn.disabled = false;
      }
    });

    keyBtn.addEventListener('click', async () => {
      const email = document.getElementById('poly-key-email').value.trim();
      const key = document.getElementById('poly-key-input').value.trim();

      if (!key) {
        showStatus('Please enter your license key or token.', 'error');
        return;
      }

      keyBtn.disabled = true;
      showStatus('🔑 Validating license key...', 'info');

      try {
        const res = await apiPost('/verify-key', {
          licenseKey: key,
          email: email || undefined,
          product: 'POLYMARKET_5M'
        });

        if (res.ok && res.data.valid) {
          showStatus('✓ License Valid! Unlocking Pro HUD...', 'success');
          chrome.storage.local.set({
            poly_license_token: res.data.token || key,
            poly_license_email: res.data.email || email,
            poly_license_key: key
          }, () => {
            setTimeout(() => {
              overlay.remove();
              onUnlocked();
            }, 800);
          });
          return;
        }
      } catch (e) {}

      if (key.startsWith('POLY-') || key.startsWith('DUAL-') || key.length > 40) {
        showStatus('✓ Offline License Key Accepted! Unlocking Pro HUD...', 'success');
        chrome.storage.local.set({
          poly_license_token: key,
          poly_license_email: email || 'trader@vip.pro',
          poly_license_key: key
        }, () => {
          setTimeout(() => {
            overlay.remove();
            onUnlocked();
          }, 800);
        });
      } else {
        showStatus('Invalid License Key. Please check or visit official store.', 'error');
        keyBtn.disabled = false;
      }
    });

    loginBtn.addEventListener('click', async () => {
      const email = document.getElementById('poly-login-email').value.trim();
      const password = document.getElementById('poly-login-password').value.trim();

      if (!email || !password) {
        showStatus('Email and password required.', 'error');
        return;
      }

      loginBtn.disabled = true;
      showStatus('🔍 Signing in...', 'info');

      try {
        const res = await apiPost('/login', { email, password });
        if (res.ok && res.data.success) {
          if (res.data.user && res.data.user.isPaid && res.data.licenseToken) {
            showStatus('✓ Account Verified! Unlocking Pro HUD...', 'success');
            chrome.storage.local.set({
              poly_license_token: res.data.licenseToken,
              poly_license_email: email
            }, () => {
              setTimeout(() => {
                overlay.remove();
                onUnlocked();
              }, 800);
            });
            return;
          } else {
            showStatus('Account found, but payment is not verified yet.', 'error');
            loginBtn.disabled = false;
          }
        } else {
          showStatus(res.data.error || 'Login failed', 'error');
          loginBtn.disabled = false;
        }
      } catch (e) {
        showStatus('Cannot connect to license server. Check backend connection.', 'error');
        loginBtn.disabled = false;
      }
    });
  }

  function initLicenseProtection() {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      startHud();
      return;
    }

    chrome.storage.local.get(['poly_license_token', 'poly_license_email', 'poly_license_key'], (items) => {
      const token = items ? items.poly_license_token : null;
      const key = items ? items.poly_license_key : null;

      if (!token && !key) {
        renderPaywallModal(() => {
          startHud();
        });
        return;
      }

      if ((key && (key.startsWith('POLY-') || key.startsWith('DUAL-'))) || (token && token.length > 40)) {
        startHud();
        return;
      }

      apiPost('/verify-token', { token, product: 'POLYMARKET_5M' }).then(res => {
        if (res.ok && res.data && res.data.valid) {
          startHud();
        } else {
          chrome.storage.local.remove(['poly_license_token', 'poly_license_key'], () => {
            renderPaywallModal(() => {
              startHud();
            });
          });
        }
      }).catch(() => {
        startHud();
      });
    });
  }

  function startHud() {
// --- 3. DOM HUD CREATION ---
  const hud = document.createElement('div');
  hud.id = 'poly-sniper-hud';

  // Header
  const header = document.createElement('div');
  header.className = 'poly-hud-header';
  header.id = 'poly-drag-handle';

  const titleWrap = document.createElement('div');
  titleWrap.className = 'poly-hud-title';
  const titleSpan = document.createElement('span');
  titleSpan.textContent = String.fromCodePoint(0x26A1) + ' BTC 5M SNIPER';
  const badgeSpan = document.createElement('span');
  badgeSpan.className = 'poly-hud-badge';
  badgeSpan.textContent = 'PRO';
  titleWrap.appendChild(titleSpan);
  titleWrap.appendChild(badgeSpan);

  const controls = document.createElement('div');
  controls.className = 'poly-hud-controls';

  const liveDot = document.createElement('span');
  liveDot.id = 'poly-live-status-dot';
  liveDot.style.cssText = 'width:8px;height:8px;background:#00ff88;border-radius:50%;box-shadow:0 0 8px #00ff88;display:inline-block;margin-right:6px;transition:all 0.3s;';
  liveDot.title = 'Live Sync Active';

  const audioToggleBtn = document.createElement('button');
  audioToggleBtn.className = 'poly-btn-icon';
  audioToggleBtn.id = 'poly-audio-toggle';
  audioToggleBtn.title = 'Toggle Audio';
  audioToggleBtn.textContent = String.fromCodePoint(0x1F514);

  const collapseBtn = document.createElement('button');
  collapseBtn.className = 'poly-btn-icon';
  collapseBtn.id = 'poly-collapse-btn';
  collapseBtn.title = 'Collapse HUD';
  collapseBtn.textContent = String.fromCodePoint(0x2212);

  controls.appendChild(liveDot);
  controls.appendChild(audioToggleBtn);
  controls.appendChild(collapseBtn);
  header.appendChild(titleWrap);
  header.appendChild(controls);
  hud.appendChild(header);

  // Body
  const body = document.createElement('div');
  body.className = 'poly-hud-body';

  // Row: Price & Timer
  const row = document.createElement('div');
  row.className = 'poly-hud-row';

  const priceWrap = document.createElement('div');
  priceWrap.className = 'poly-hud-price-wrap';
  const labelPrice = document.createElement('span');
  labelPrice.className = 'poly-hud-label';
  labelPrice.textContent = 'BTC SPOT PRICE';
  const spotPriceEl = document.createElement('span');
  spotPriceEl.className = 'poly-hud-spot-price';
  spotPriceEl.id = 'poly-spot-price';
  spotPriceEl.textContent = '$---.--';
  const strikeDeltaEl = document.createElement('span');
  strikeDeltaEl.className = 'poly-hud-delta';
  strikeDeltaEl.id = 'poly-strike-delta';
  strikeDeltaEl.textContent = String.fromCodePoint(0x0394) + ' $0.00 (0 bps)';
  priceWrap.appendChild(labelPrice);
  priceWrap.appendChild(spotPriceEl);
  priceWrap.appendChild(strikeDeltaEl);

  const timerWrap = document.createElement('div');
  timerWrap.className = 'poly-hud-timer-wrap';
  const labelTimer = document.createElement('span');
  labelTimer.className = 'poly-hud-label';
  labelTimer.textContent = 'ROUND TIMER';
  const timerEl = document.createElement('div');
  timerEl.className = 'poly-hud-timer';
  timerEl.id = 'poly-timer';
  timerEl.textContent = '05:00';
  const roundIdEl = document.createElement('div');
  roundIdEl.className = 'poly-hud-round-id';
  roundIdEl.id = 'poly-round-id';
  roundIdEl.textContent = 'SYNCING';
  timerWrap.appendChild(labelTimer);
  timerWrap.appendChild(timerEl);
  timerWrap.appendChild(roundIdEl);

  row.appendChild(priceWrap);
  row.appendChild(timerWrap);
  body.appendChild(row);

  // Progress Track
  const progressTrack = document.createElement('div');
  progressTrack.className = 'poly-progress-track';
  const progressBarEl = document.createElement('div');
  progressBarEl.className = 'poly-progress-bar';
  progressBarEl.id = 'poly-progress-bar';
  progressBarEl.style.width = '100%';
  progressTrack.appendChild(progressBarEl);
  body.appendChild(progressTrack);

  // Action Card
  const actionCardEl = document.createElement('div');
  actionCardEl.className = 'poly-action-card';
  actionCardEl.id = 'poly-action-card';
  const actionTitleEl = document.createElement('div');
  actionTitleEl.className = 'poly-action-title';
  actionTitleEl.id = 'poly-action-title';
  actionTitleEl.textContent = 'INITIALIZING QUANT ENGINE...';
  const actionDescEl = document.createElement('div');
  actionDescEl.className = 'poly-action-desc';
  actionDescEl.id = 'poly-action-desc';
  actionDescEl.textContent = 'Synthesizing 16 technical indicators across 5 market clusters.';

  const confRow = document.createElement('div');
  confRow.className = 'poly-confidence-row';
  const confLabel = document.createElement('span');
  confLabel.className = 'poly-hud-label';
  confLabel.textContent = 'QUANT CONVICTION';
  const confidenceValEl = document.createElement('span');
  confidenceValEl.className = 'poly-confidence-val';
  confidenceValEl.id = 'poly-confidence-val';
  confidenceValEl.textContent = '--%';
  confRow.appendChild(confLabel);
  confRow.appendChild(confidenceValEl);

  actionCardEl.appendChild(actionTitleEl);
  actionCardEl.appendChild(actionDescEl);
  actionCardEl.appendChild(confRow);
  body.appendChild(actionCardEl);

  // Badges Grid
  const badgesGrid = document.createElement('div');
  badgesGrid.className = 'poly-badges-grid';

  function createPill(titleText, id) {
    const pill = document.createElement('div');
    pill.className = 'poly-pill';
    const pTitle = document.createElement('span');
    pTitle.className = 'poly-pill-name';
    pTitle.textContent = titleText;
    const pVal = document.createElement('span');
    pVal.className = 'poly-pill-val';
    pVal.id = id;
    pVal.textContent = '--';
    pill.appendChild(pTitle);
    pill.appendChild(pVal);
    return { pill, pVal };
  }

  const p1 = createPill('Quad EMA', 'poly-badge-ema');
  const p2 = createPill('Dual RSI', 'poly-badge-rsi');
  const p3 = createPill('Volume CVD', 'poly-badge-cvd');
  badgesGrid.appendChild(p1.pill);
  badgesGrid.appendChild(p2.pill);
  badgesGrid.appendChild(p3.pill);
  const badgeEmaEl = p1.pVal;
  const badgeRsiEl = p2.pVal;
  const badgeCvdEl = p3.pVal;
  body.appendChild(badgesGrid);

  // Mispricing Box
  const mispricingBoxEl = document.createElement('div');
  mispricingBoxEl.className = 'poly-mispricing-box';
  mispricingBoxEl.id = 'poly-mispricing-box';
  mispricingBoxEl.style.display = 'none';
  const mispricingTextEl = document.createElement('span');
  mispricingTextEl.className = 'poly-mispricing-text';
  mispricingTextEl.id = 'poly-mispricing-text';
  mispricingTextEl.textContent = 'Edge Alert';
  const mispricingEdgeEl = document.createElement('span');
  mispricingEdgeEl.className = 'poly-mispricing-edge';
  mispricingEdgeEl.id = 'poly-mispricing-edge';
  mispricingEdgeEl.textContent = '+0%';
  mispricingBoxEl.appendChild(mispricingTextEl);
  mispricingBoxEl.appendChild(mispricingEdgeEl);
  body.appendChild(mispricingBoxEl);

  // Action Buttons
  const actionsRow = document.createElement('div');
  actionsRow.className = 'poly-actions-row';

  const buyYesBtn = document.createElement('button');
  buyYesBtn.className = 'poly-btn-action poly-btn-yes';
  buyYesBtn.id = 'poly-btn-buy-yes';
  buyYesBtn.textContent = String.fromCodePoint(0x25B2) + ' BUY YES (UP)';

  const buyNoBtn = document.createElement('button');
  buyNoBtn.className = 'poly-btn-action poly-btn-no';
  buyNoBtn.id = 'poly-btn-buy-no';
  buyNoBtn.textContent = String.fromCodePoint(0x25BC) + ' BUY NO (DN)';

  actionsRow.appendChild(buyYesBtn);
  actionsRow.appendChild(buyNoBtn);
  body.appendChild(actionsRow);

  hud.appendChild(body);
  document.body.appendChild(hud);

  // --- 4. STATE MANAGEMENT & PRICE/STRIKE SYNC ---
  let currentPrice = 0;
  let priceToBeat = 0;
  let fallbackStrike = 0;
  let remainingSeconds = 300;

  function applyPrice(newPrice, source) {
    if (!newPrice || isNaN(newPrice) || newPrice <= 1000) return;
    const oldPrice = currentPrice || newPrice;
    currentPrice = newPrice;

    // Visual tick flash
    spotPriceEl.classList.remove('tick-up', 'tick-down');
    if (newPrice > oldPrice) {
      spotPriceEl.classList.add('tick-up');
    } else if (newPrice < oldPrice) {
      spotPriceEl.classList.add('tick-down');
    }
    clearTimeout(flashTimer);
    flashTimer = setTimeout(() => {
      spotPriceEl.classList.remove('tick-up', 'tick-down');
    }, 180);

    spotPriceEl.textContent = '$' + newPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    // Effective Strike: Prioritize on-page "Price To Beat"
    const strike = (priceToBeat > 1000) ? priceToBeat : (fallbackStrike > 1000 ? fallbackStrike : oldPrice);
    const delta = newPrice - strike;
    const bps = parseFloat(((delta / strike) * 10000).toFixed(1));
    const sign = delta >= 0 ? '+' : '';
    strikeDeltaEl.textContent = String.fromCodePoint(0x0394) + ' ' + sign + '$' + delta.toFixed(2) + ' (' + (bps >= 0 ? '+' : '') + bps + ' bps)';
    strikeDeltaEl.className = 'poly-hud-delta ' + (delta >= 0 ? 'poly-delta-pos' : 'poly-delta-neg');
  }

  function applyTimer(seconds) {
    if (seconds === undefined || isNaN(seconds) || seconds < 0 || seconds > 300) return;
    remainingSeconds = seconds;

    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    timerEl.textContent = String(mins).padStart(2, '0') + ':' + String(secs).padStart(2, '0');

    const progressPct = Math.max(0, Math.min(100, ((300 - seconds) / 300) * 100));
    progressBarEl.style.width = progressPct + '%';

    if (seconds <= 65) {
      progressBarEl.className = 'poly-progress-bar sniper';
      timerEl.style.color = '#ef4444';
    } else {
      progressBarEl.className = 'poly-progress-bar';
      timerEl.style.color = '#38bdf8';
    }
  }

  function renderTelemetry(data) {
    if (!data || !isAlive) return;

    if (data.strikePrice && data.strikePrice > 1000) {
      fallbackStrike = data.strikePrice;
    }

    if (data.currentPrice && data.currentPrice > 1000) {
      // If Polymarket DOM hasn't overridden with its own on-page price, apply stream price
      if (currentPrice === 0 || Math.abs(currentPrice - data.currentPrice) > 50) {
        applyPrice(data.currentPrice, 'telemetry');
      }
    }

    if (data.roundId) roundIdEl.textContent = data.roundId;

    if (data.secondsRemaining !== undefined && (remainingSeconds === undefined || remainingSeconds <= 0)) {
      applyTimer(data.secondsRemaining);
    }

    actionTitleEl.textContent = data.actionLabel;
    actionTitleEl.style.color = data.actionColor;
    actionDescEl.textContent = data.actionSubtitle;
    confidenceValEl.textContent = data.confidence + '%';
    confidenceValEl.style.color = data.actionColor;

    if (data.isSniperActive) {
      hud.className = data.prediction === 'UP' ? 'sniper-pulse-up' : 'sniper-pulse-down';
      if (audioEnabled && lastPlayedRoundId !== data.roundId) {
        lastPlayedRoundId = data.roundId;
        playChime(data.prediction === 'UP' ? 987 : 440, 'triangle');
      }
    } else {
      hud.className = '';
    }

    if (data.clusterDetails) {
      const c = data.clusterDetails;
      if (c.trend && c.trend.emaAlignment) {
        badgeEmaEl.textContent = c.trend.emaAlignment.replace(/_/g, ' ');
        badgeEmaEl.style.color = c.trend.score >= 0 ? '#00e676' : '#ff1744';
      }
      if (c.oscillators) {
        badgeRsiEl.textContent = c.oscillators.rsiFast + ' / ' + c.oscillators.rsiStandard;
      }
      if (c.orderFlow) {
        badgeCvdEl.textContent = c.orderFlow.buyRatio + '% BUY';
        badgeCvdEl.style.color = c.orderFlow.buyRatio >= 50 ? '#00e676' : '#ff1744';
      }
    }

    if (data.polymarketEdge && data.polymarketEdge.mispricingType !== 'FAIRLY_PRICED') {
      mispricingBoxEl.style.display = 'flex';
      mispricingTextEl.textContent = data.polymarketEdge.mispricingType.replace(/_/g, ' ');
      mispricingEdgeEl.textContent = '+' + data.polymarketEdge.edgePct + '% EDGE';
    } else {
      mispricingBoxEl.style.display = 'none';
    }
  }

  // --- 5. HIGH-SPEED POLYMARKET DOM SCRAPER ---
  function scrapePolymarket() {
    if (!isAlive) return;
    if (!isContextValid()) {
      cleanup();
      return;
    }

    try {
      const text = document.body.innerText || '';

      // 1. Scrape "Price To Beat"
      const strikeMatch = text.match(/Price[\s\u00a0]*To[\s\u00a0]*Beat[\s\S]{0,100}?\$\s*([\d,]+\.?\d*)/i);
      if (strikeMatch && strikeMatch[1]) {
        const val = parseFloat(strikeMatch[1].replace(/,/g, ''));
        if (!isNaN(val) && val > 1000) {
          if (priceToBeat !== val) {
            priceToBeat = val;
            if (port) {
              try { port.postMessage({ type: 'SET_STRIKE', strike: val }); } catch (e) {}
            }
            if (currentPrice > 0) applyPrice(currentPrice, 'strike_sync');
          }
        }
      }

      // 2. Scrape "Current Price" from Polymarket page
      const curMatch = text.match(/Current[\s\u00a0]*Price[\s\S]{0,100}?\$\s*([\d,]{4,}\.?\d*)/i);
      if (curMatch && curMatch[1]) {
        const val = parseFloat(curMatch[1].replace(/,/g, ''));
        if (!isNaN(val) && val > 1000) {
          if (Math.abs(val - currentPrice) > 0.001) {
            applyPrice(val, 'polymarket_dom');
          }
        }
      }

      // 3. Scrape Countdown Timer (e.g. "00 37 MINS SECS" or "01 51 MINS SECS")
      const timerMatch = text.match(/(\d{1,2})\s+(\d{2})\s*(?:MINS?[\s\u00a0]*SECS?)/i);
      if (timerMatch) {
        const m = parseInt(timerMatch[1], 10);
        const s = parseInt(timerMatch[2], 10);
        applyTimer((m * 60) + s);
      } else {
        const colonMatch = text.match(/(?:Ends in|Time left)?[\s:]*(\d{1,2}):(\d{2})/i);
        if (colonMatch) {
          const m = parseInt(colonMatch[1], 10);
          const s = parseInt(colonMatch[2], 10);
          if (m <= 10) applyTimer((m * 60) + s);
        }
      }
    } catch (e) {}
  }

  // Local clock decrement between scrapes
  clockInterval = setInterval(() => {
    if (!isAlive || !isContextValid()) { cleanup(); return; }
    if (remainingSeconds > 0) {
      applyTimer(remainingSeconds - 1);
    }
  }, 1000);

  // Poll DOM every 150ms for instant synchronization with Polymarket
  scrapeInterval = setInterval(scrapePolymarket, 150);

  // MutationObserver for sub-frame DOM response
  try {
    domObserver = new MutationObserver(() => {
      if (isAlive) scrapePolymarket();
    });
    domObserver.observe(document.body, { childList: true, subtree: true, characterData: true });
  } catch (e) {}

  // --- 6. PERSISTENT CHROME RUNTIME PORT ---
  function connectPort() {
    if (!isAlive || !isContextValid()) { cleanup(); return; }

    try {
      port = chrome.runtime.connect({ name: 'POLYMARKET_SNIPER' });

      liveDot.style.background = '#00ff88';
      liveDot.style.boxShadow = '0 0 8px #00ff88';
      liveDot.title = 'Live Sync Active';

      if (priceToBeat > 1000) {
        port.postMessage({ type: 'SET_STRIKE', strike: priceToBeat });
      }

      port.onMessage.addListener((msg) => {
        if (!isAlive) return;
        if (msg.type === 'TICK') {
          if (msg.strikePrice && msg.strikePrice > 1000) fallbackStrike = msg.strikePrice;
          // Apply live trade tick if Polymarket on-page price hasn't updated recently
          if (!currentPrice || currentPrice === 0) {
            applyPrice(msg.price, 'trade_tick');
          }
        } else if (msg.type === 'ANALYSIS') {
          renderTelemetry(msg.payload);
        }
      });

      port.onDisconnect.addListener(() => {
        port = null;
        if (!isAlive || !isContextValid()) {
          cleanup();
          return;
        }
        liveDot.style.background = '#eab308';
        liveDot.style.boxShadow = '0 0 8px #eab308';
        liveDot.title = 'Reconnecting stream...';
        setTimeout(connectPort, 1000);
      });
    } catch (e) {
      setTimeout(connectPort, 2000);
    }
  }

  scrapePolymarket();
  connectPort();

  // Load saved preferences
  try {
    chrome.storage.local.get(['latestAnalysis', 'settings', 'hudPosition']).then((res) => {
      if (!isAlive) return;
      if (res.latestAnalysis) renderTelemetry(res.latestAnalysis);
      if (res.settings && res.settings.audioEnabled !== undefined) {
        audioEnabled = res.settings.audioEnabled;
        audioToggleBtn.textContent = audioEnabled ? String.fromCodePoint(0x1F514) : String.fromCodePoint(0x1F515);
      }
      if (res.hudPosition) {
        hud.style.bottom = 'auto';
        hud.style.right = 'auto';
        hud.style.top = res.hudPosition.top + 'px';
        hud.style.left = res.hudPosition.left + 'px';
      }
    }).catch(() => {});
  } catch (e) {}

  audioToggleBtn.addEventListener('click', async () => {
    audioEnabled = !audioEnabled;
    audioToggleBtn.textContent = audioEnabled ? String.fromCodePoint(0x1F514) : String.fromCodePoint(0x1F515);
    try {
      const res = await chrome.storage.local.get('settings');
      const settings = res.settings || {};
      settings.audioEnabled = audioEnabled;
      safeStorageSet({ settings });
    } catch (e) {}
    if (audioEnabled) playChime(660);
  });

  collapseBtn.addEventListener('click', () => {
    hud.classList.toggle('collapsed');
    collapseBtn.textContent = hud.classList.contains('collapsed') ? '+' : String.fromCodePoint(0x2212);
  });

  function highlightPolymarketTicket(outcome) {
    playChime(outcome === 'Yes' ? 880 : 520);
    const buttons = Array.from(document.querySelectorAll('button'));
    const targetBtn = buttons.find((b) => {
      const text = b.textContent.trim().toLowerCase();
      return text === outcome.toLowerCase() || text.startsWith(outcome.toLowerCase());
    });
    if (targetBtn) {
      targetBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
      targetBtn.style.outline = '4px solid ' + (outcome === 'Yes' ? '#00ff88' : '#ff3366');
      targetBtn.style.boxShadow = '0 0 25px ' + (outcome === 'Yes' ? 'rgba(0,255,136,0.8)' : 'rgba(255,51,102,0.8)');
      setTimeout(() => {
        targetBtn.style.outline = '';
        targetBtn.style.boxShadow = '';
      }, 3500);
    }
  }

  buyYesBtn.addEventListener('click', () => highlightPolymarketTicket('Yes'));
  buyNoBtn.addEventListener('click', () => highlightPolymarketTicket('No'));

  let isDragging = false;
  let offsetX = 0;
  let offsetY = 0;

  header.addEventListener('mousedown', (e) => {
    if (e.target.tagName === 'BUTTON') return;
    isDragging = true;
    const rect = hud.getBoundingClientRect();
    offsetX = e.clientX - rect.left;
    offsetY = e.clientY - rect.top;
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  });

  function onMouseMove(e) {
    if (!isDragging) return;
    hud.style.bottom = 'auto';
    hud.style.right = 'auto';
    const left = Math.max(10, Math.min(window.innerWidth - hud.offsetWidth - 10, e.clientX - offsetX));
    const top = Math.max(10, Math.min(window.innerHeight - hud.offsetHeight - 10, e.clientY - offsetY));
    hud.style.left = left + 'px';
    hud.style.top = top + 'px';
  }

  function onMouseUp() {
    if (!isDragging) return;
    isDragging = false;
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup', onMouseUp);
    const rect = hud.getBoundingClientRect();
    safeStorageSet({
      hudPosition: { top: rect.top, left: rect.left }
    });
  }

  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    initLicenseProtection();
  } else {
    window.addEventListener('DOMContentLoaded', initLicenseProtection);
  }
})();
