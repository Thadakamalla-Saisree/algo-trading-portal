/**
 * Polymarket BTC 5-Minute Prediction Engine
 * Background Service Worker (Manifest V3)
 * 
 * - Manages low-latency Binance WebSocket stream (exempt from page CSP)
 * - Keeps worker alive via chrome.runtime.connect ports from active Polymarket tabs
 * - Streams live price ticks & master quant signals directly to content HUD & popup
 * - Accepts on-page "Price To Beat" scraped by content script for perfect strike sync
 */

importScripts('../engine/indicators.js', '../engine/quantEngine.js');

const quantEngine = new QuantEngine();

let liveSocket = null;
let reconnectTimer = null;
let lastAnalysis = null;
let lastPrice = 0;
let candlesBuffer = [];
let tradesBuffer = [];
let polymarketOdds = null;
let lastStrikeRoundId = null;
let currentStrikePrice = 0;
let lastNotifiedRoundId = null;

const connectedPorts = new Set();

chrome.runtime.onInstalled.addListener(async () => {
  console.log('[Service Worker] Installed.');
  await chrome.storage.local.set({
    settings: {
      minConfidence: 80,
      audioEnabled: true,
      notificationsEnabled: true,
      overlayEnabled: true
    },
    sessionStats: {
      totalSignals: 0,
      wins: 0,
      losses: 0,
      winRate: 0,
      streak: 0,
      lastUpdated: Date.now()
    }
  });

  chrome.alarms.create('polymarketHeartbeat', { periodInMinutes: 1 });
  await initializeFeed();
});

chrome.runtime.onStartup.addListener(async () => {
  await initializeFeed();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'polymarketHeartbeat') {
    maintainState();
  }
});

async function initializeFeed() {
  await backfillCandles();
  await fetchPolymarketOdds();
  connectBinanceWebSocket();
}

async function backfillCandles() {
  try {
    const url = 'https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1m&limit=60';
    const res = await fetch(url);
    if (!res.ok) return;
    const raw = await res.json();
    candlesBuffer = raw.map(k => ({
      time: k[0],
      open: parseFloat(k[1]),
      high: parseFloat(k[2]),
      low: parseFloat(k[3]),
      close: parseFloat(k[4]),
      volume: parseFloat(k[5])
    }));
    if (candlesBuffer.length > 0) {
      lastPrice = candlesBuffer[candlesBuffer.length - 1].close;
    }
    console.log('[Service Worker] Backfilled ' + candlesBuffer.length + ' 1m candles.');
  } catch (err) {
    console.error('[Service Worker] Candle backfill error:', err);
  }
}

async function fetchPolymarketOdds() {
  try {
    const url = 'https://gamma-api.polymarket.com/events?closed=false&limit=10&q=bitcoin';
    const res = await fetch(url);
    if (!res.ok) return;
    const events = await res.json();

    if (events && events.length > 0) {
      const btcEvent = events[0];
      if (btcEvent.markets && btcEvent.markets.length > 0) {
        const m = btcEvent.markets[0];
        let yesPrice = 0.50;
        let noPrice = 0.50;
        if (m.outcomePrices) {
          try {
            const prices = JSON.parse(m.outcomePrices);
            yesPrice = parseFloat(prices[0]) || 0.50;
            noPrice = parseFloat(prices[1]) || (1 - yesPrice);
          } catch (e) {
            yesPrice = parseFloat(m.outcomePrices[0]) || 0.50;
          }
        }
        polymarketOdds = {
          marketTitle: btcEvent.title || 'Bitcoin 5-Min Price',
          slug: btcEvent.slug,
          yesPrice,
          noPrice
        };
      }
    }
  } catch (err) {
    polymarketOdds = {
      marketTitle: 'BTC Up or Down 5-Min',
      slug: 'btc-5m-live',
      yesPrice: 0.50,
      noPrice: 0.50
    };
  }
}

function connectBinanceWebSocket() {
  if (liveSocket && (liveSocket.readyState === WebSocket.OPEN || liveSocket.readyState === WebSocket.CONNECTING)) {
    return;
  }

  const streamUrl = 'wss://stream.binance.com:9443/ws/btcusdt@kline_1m/btcusdt@trade';
  try {
    liveSocket = new WebSocket(streamUrl);

    liveSocket.onopen = () => {
      console.log('[Service Worker] Binance WebSocket Connected.');
    };

    liveSocket.onmessage = async (event) => {
      try {
        const msg = JSON.parse(event.data);

        if (msg.e === 'trade') {
          const price = parseFloat(msg.p);
          const qty = parseFloat(msg.q);
          const isBuyerMaker = msg.m;
          lastPrice = price;

          tradesBuffer.push({
            price,
            volume: qty,
            isBuyerMaker,
            timestamp: msg.T
          });
          if (tradesBuffer.length > 300) tradesBuffer.shift();

          broadcastToPorts({
            type: 'TICK',
            price,
            strikePrice: currentStrikePrice
          });

          if (tradesBuffer.length % 3 === 0) {
            await processTick(price);
          }
        }

        if (msg.e === 'kline') {
          const k = msg.k;
          const candle = {
            time: k.t,
            open: parseFloat(k.o),
            high: parseFloat(k.h),
            low: parseFloat(k.l),
            close: parseFloat(k.c),
            volume: parseFloat(k.v),
            isClosed: k.x
          };

          if (candlesBuffer.length > 0) {
            const lastCandle = candlesBuffer[candlesBuffer.length - 1];
            if (lastCandle.time === candle.time) {
              candlesBuffer[candlesBuffer.length - 1] = candle;
            } else {
              candlesBuffer.push(candle);
              if (candlesBuffer.length > 80) candlesBuffer.shift();
            }
          } else {
            candlesBuffer.push(candle);
          }
        }
      } catch (e) {
        console.error('[Service Worker] Parse tick error:', e);
      }
    };

    liveSocket.onerror = (err) => {
      console.error('[Service Worker] WebSocket error:', err);
    };

    liveSocket.onclose = () => {
      console.log('[Service Worker] WebSocket closed. Reconnecting in 2s...');
      clearTimeout(reconnectTimer);
      reconnectTimer = setTimeout(connectBinanceWebSocket, 2000);
    };
  } catch (err) {
    console.error('[Service Worker] Socket connection failed:', err);
  }
}

async function processTick(currentPrice) {
  if (!candlesBuffer || candlesBuffer.length < 5) return;

  const nowSec = Math.floor(Date.now() / 1000);
  const roundStartSec = nowSec - (nowSec % 300);
  const date = new Date(roundStartSec * 1000);
  const hours = String(date.getUTCHours()).padStart(2, '0');
  const mins = String(date.getUTCMinutes()).padStart(2, '0');
  const roundId = '5M_' + hours + mins;

  if (roundId !== lastStrikeRoundId) {
    lastStrikeRoundId = roundId;
    if (!currentStrikePrice || currentStrikePrice === 0) {
      currentStrikePrice = currentPrice;
    }
    fetchPolymarketOdds();
  }

  const effectiveStrike = (currentStrikePrice > 1000) ? currentStrikePrice : currentPrice;

  const analysis = quantEngine.analyzeRound({
    candles1m: candlesBuffer,
    currentPrice,
    strikePrice: effectiveStrike,
    trades: tradesBuffer,
    polymarketOdds,
    serverTimeSec: nowSec
  });

  lastAnalysis = analysis;

  await chrome.storage.local.set({
    latestAnalysis: analysis,
    currentPrice,
    strikePrice: effectiveStrike,
    lastUpdate: Date.now()
  });

  updateBadge(analysis);

  if (analysis.isSniperActive && roundId !== lastNotifiedRoundId) {
    lastNotifiedRoundId = roundId;
    await triggerSniperNotification(analysis);
  }

  broadcastToPorts({
    type: 'ANALYSIS',
    payload: analysis
  });
  chrome.runtime.sendMessage({
    type: 'TELEMETRY_UPDATE',
    payload: analysis
  }).catch(() => {});
}

function updateBadge(analysis) {
  try {
    if (!analysis) return;
    if (analysis.prediction === 'UP') {
      chrome.action.setBadgeText({ text: 'UP' });
      chrome.action.setBadgeBackgroundColor({ color: '#00e676' });
    } else if (analysis.prediction === 'DOWN') {
      chrome.action.setBadgeText({ text: 'DN' });
      chrome.action.setBadgeBackgroundColor({ color: '#ff1744' });
    } else {
      const mins = Math.ceil((analysis.secondsRemaining || 300) / 60);
      chrome.action.setBadgeText({ text: String(mins) + 'm' });
      chrome.action.setBadgeBackgroundColor({ color: '#374151' });
    }
  } catch (e) {}
}

async function triggerSniperNotification(analysis) {
  try {
    const { settings } = await chrome.storage.local.get('settings');
    if (settings && settings.notificationsEnabled === false) return;

    const isUp = analysis.prediction === 'UP';
    const title = isUp ? 'Polymarket Sniper: CALL (UP)' : 'Polymarket Sniper: PUT (DOWN)';
    const message = 'Confidence: ' + analysis.confidence + '% | Delta: ' + (analysis.strikeDelta >= 0 ? '+' : '') + '$' + analysis.strikeDelta.toFixed(2) + ' | ' + analysis.secondsRemaining + 's left!';

    chrome.notifications.create('sniper_' + Date.now(), {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icons/icon-128.png'),
      title,
      message,
      priority: 2
    });
  } catch (err) {}
}

function maintainState() {
  if (!liveSocket || liveSocket.readyState !== WebSocket.OPEN) {
    connectBinanceWebSocket();
  }
}

function broadcastToPorts(msg) {
  for (const port of connectedPorts) {
    try {
      port.postMessage(msg);
    } catch (e) {
      connectedPorts.delete(port);
    }
  }
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === 'POLYMARKET_SNIPER') {
    connectedPorts.add(port);

    if (lastPrice > 0) {
      port.postMessage({ type: 'TICK', price: lastPrice, strikePrice: currentStrikePrice });
    }
    if (lastAnalysis) {
      port.postMessage({ type: 'ANALYSIS', payload: lastAnalysis });
    }

    port.onMessage.addListener((msg) => {
      if (msg.type === 'SET_STRIKE' && msg.strike && msg.strike > 1000) {
        currentStrikePrice = msg.strike;
        if (lastPrice > 0) {
          processTick(lastPrice);
        }
      }
    });

    port.onDisconnect.addListener(() => {
      connectedPorts.delete(port);
    });
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'GET_LATEST_ANALYSIS') {
    sendResponse({ analysis: lastAnalysis });
    return false;
  }
  if (request.type === 'RECORD_ROUND_RESULT') {
    (async () => {
      const { sessionStats = { totalSignals: 0, wins: 0, losses: 0, winRate: 0, streak: 0 } } = await chrome.storage.local.get('sessionStats');
      sessionStats.totalSignals += 1;
      if (request.isWin) {
        sessionStats.wins += 1;
        sessionStats.streak = (sessionStats.streak >= 0 ? sessionStats.streak + 1 : 1);
      } else {
        sessionStats.losses += 1;
        sessionStats.streak = (sessionStats.streak <= 0 ? sessionStats.streak - 1 : -1);
      }
      sessionStats.winRate = parseFloat(((sessionStats.wins / sessionStats.totalSignals) * 100).toFixed(1));
      sessionStats.lastUpdated = Date.now();
      await chrome.storage.local.set({ sessionStats });
      sendResponse({ success: true, sessionStats });
    })();
    return true;
  }
});
