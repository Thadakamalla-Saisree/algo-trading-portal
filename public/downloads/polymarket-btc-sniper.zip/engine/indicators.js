/**
 * Polymarket BTC 5-Minute Prediction Engine
 * 16-Pillar Quantitative Confluence & Technical Indicator Suite
 */

class IndicatorSuite {
  static calculateSMA(values, period) {
    if (!values || values.length === 0) return 0;
    const p = Math.min(period, values.length);
    let sum = 0;
    for (let i = values.length - p; i < values.length; i++) {
      sum += values[i];
    }
    return sum / p;
  }

  static calculateEMASeries(values, period) {
    if (!values || values.length === 0) return [];
    const p = Math.max(2, Math.min(period, values.length));
    const k = 2 / (p + 1);
    const series = new Array(values.length);
    let sum = 0;
    const seedLen = Math.min(p, values.length);
    for (let i = 0; i < seedLen; i++) {
      sum += values[i];
      series[i] = sum / (i + 1);
    }
    for (let i = seedLen; i < values.length; i++) {
      series[i] = (values[i] * k) + (series[i - 1] * (1 - k));
    }
    return series;
  }

  static calculateEMA(values, period) {
    const series = this.calculateEMASeries(values, period);
    return series.length > 0 ? series[series.length - 1] : 0;
  }

  static calculateStandardDeviation(values, period) {
    if (!values || values.length === 0) return 0;
    const p = Math.min(period, values.length);
    const mean = this.calculateSMA(values, p);
    let sumSqDiff = 0;
    for (let i = values.length - p; i < values.length; i++) {
      sumSqDiff += Math.pow(values[i] - mean, 2);
    }
    return Math.sqrt(sumSqDiff / p);
  }

  // 1. Quad EMA Ribbon (3, 8, 21, 50)
  static calculateEMARibbon(candles) {
    if (!candles || candles.length < 8) {
      return { score: 0, alignment: 'NEUTRAL', ema3: 0, ema8: 0, ema21: 0, ema50: 0 };
    }
    const closes = candles.map(c => c.close);
    const ema3 = this.calculateEMA(closes, 3);
    const ema8 = this.calculateEMA(closes, 8);
    const ema21 = this.calculateEMA(closes, 21);
    const ema50 = this.calculateEMA(closes, Math.min(50, closes.length));
    const currentPrice = closes[closes.length - 1];

    let score = 0;
    let alignment = 'NEUTRAL';
    if (currentPrice > ema3 && ema3 > ema8 && ema8 > ema21 && ema21 >= ema50) {
      score = 1.0;
      alignment = 'STRONG_BULLISH';
    } else if (currentPrice < ema3 && ema3 < ema8 && ema8 < ema21 && ema21 <= ema50) {
      score = -1.0;
      alignment = 'STRONG_BEARISH';
    } else if (ema3 > ema8 && currentPrice > ema21) {
      score = 0.5;
      alignment = 'MODERATE_BULLISH';
    } else if (ema3 < ema8 && currentPrice < ema21) {
      score = -0.5;
      alignment = 'MODERATE_BEARISH';
    }

    return {
      score,
      alignment,
      ema3: parseFloat(ema3.toFixed(2)),
      ema8: parseFloat(ema8.toFixed(2)),
      ema21: parseFloat(ema21.toFixed(2)),
      ema50: parseFloat(ema50.toFixed(2))
    };
  }

  // 2. SuperTrend (10, 3.0 ATR)
  static calculateSuperTrend(candles, period = 10, multiplier = 3.0) {
    if (!candles || candles.length < period) {
      return { trend: 'NEUTRAL', score: 0, upperBand: 0, lowerBand: 0 };
    }
    const atr = this.calculateATR(candles, period);
    const len = candles.length;
    let inUpTrend = true;
    let lowerBand = 0;
    let upperBand = 0;

    for (let i = Math.max(0, len - period * 2); i < len; i++) {
      const c = candles[i];
      const hl2 = (c.high + c.low) / 2;
      const basicUpper = hl2 + (multiplier * atr);
      const basicLower = hl2 - (multiplier * atr);
      const prevClose = i > 0 ? candles[i - 1].close : c.close;
      const prevLower = lowerBand;
      const prevUpper = upperBand;

      lowerBand = (basicLower > prevLower || prevClose < prevLower) ? basicLower : prevLower;
      upperBand = (basicUpper < prevUpper || prevClose > prevUpper) ? basicUpper : prevUpper;

      if (inUpTrend) {
        if (c.close < lowerBand) inUpTrend = false;
      } else {
        if (c.close > upperBand) inUpTrend = true;
      }
    }

    return {
      trend: inUpTrend ? 'BULLISH' : 'BEARISH',
      score: inUpTrend ? 1.0 : -1.0,
      upperBand: parseFloat(upperBand.toFixed(2)),
      lowerBand: parseFloat(lowerBand.toFixed(2))
    };
  }

  // 3. ADX & DMI (14)
  static calculateADX(candles, period = 14) {
    if (!candles || candles.length < period + 2) {
      return { adx: 20, plusDI: 20, minusDI: 20, isTrending: false, score: 0 };
    }
    let trSum = 0;
    let plusDMSum = 0;
    let minusDMSum = 0;
    const startIdx = Math.max(1, candles.length - (period * 2));
    for (let i = startIdx; i < candles.length; i++) {
      const curr = candles[i];
      const prev = candles[i - 1];
      const tr = Math.max(
        curr.high - curr.low,
        Math.abs(curr.high - prev.close),
        Math.abs(curr.low - prev.close)
      );
      const upMove = curr.high - prev.high;
      const downMove = prev.low - curr.low;
      const plusDM = (upMove > downMove && upMove > 0) ? upMove : 0;
      const minusDM = (downMove > upMove && downMove > 0) ? downMove : 0;
      trSum += tr;
      plusDMSum += plusDM;
      minusDMSum += minusDM;
    }
    const safeTR = trSum > 0 ? trSum : 1;
    const plusDI = (plusDMSum / safeTR) * 100;
    const minusDI = (minusDMSum / safeTR) * 100;
    const diDiff = Math.abs(plusDI - minusDI);
    const diSum = (plusDI + minusDI) > 0 ? (plusDI + minusDI) : 1;
    const dx = (diDiff / diSum) * 100;
    const adx = Math.min(100, Math.max(0, dx));
    const isTrending = adx > 25;
    let score = 0;
    if (plusDI > minusDI) score = isTrending ? 1.0 : 0.4;
    else if (minusDI > plusDI) score = isTrending ? -1.0 : -0.4;

    return {
      adx: parseFloat(adx.toFixed(1)),
      plusDI: parseFloat(plusDI.toFixed(1)),
      minusDI: parseFloat(minusDI.toFixed(1)),
      isTrending,
      score
    };
  }

  // 4. Linear Regression Slope (14)
  static calculateLinearRegression(candles, period = 14) {
    if (!candles || candles.length < period) return { slope: 0, r2: 0, score: 0 };
    const subset = candles.slice(-period);
    const n = subset.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0, sumYY = 0;
    for (let i = 0; i < n; i++) {
      const x = i;
      const y = subset[i].close;
      sumX += x;
      sumY += y;
      sumXY += x * y;
      sumXX += x * x;
      sumYY += y * y;
    }
    const denominator = (n * sumXX - sumX * sumX);
    const slope = denominator !== 0 ? (n * sumXY - sumX * sumY) / denominator : 0;
    const numR = (n * sumXY - sumX * sumY);
    const denR = Math.sqrt(Math.max(1e-9, (n * sumXX - sumX * sumX) * (n * sumYY - sumY * sumY)));
    const r = denR !== 0 ? numR / denR : 0;
    const r2 = Math.min(1, Math.max(0, r * r));
    let score = 0;
    if (slope > 0) score = r2 > 0.6 ? 1.0 : 0.5;
    else if (slope < 0) score = r2 > 0.6 ? -1.0 : -0.5;

    return { slope: parseFloat(slope.toFixed(4)), r2: parseFloat(r2.toFixed(3)), score };
  }

  // 5. Dual RSI (7 & 14)
  static calculateRSI(values, period = 14) {
    if (!values || values.length < period + 1) return 50;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) {
      const diff = values[i] - values[i - 1];
      if (diff >= 0) gains += diff;
      else losses += Math.abs(diff);
    }
    let avgGain = gains / period;
    let avgLoss = losses / period;
    for (let i = period + 1; i < values.length; i++) {
      const diff = values[i] - values[i - 1];
      const gain = diff >= 0 ? diff : 0;
      const loss = diff < 0 ? Math.abs(diff) : 0;
      avgGain = (avgGain * (period - 1) + gain) / period;
      avgLoss = (avgLoss * (period - 1) + loss) / period;
    }
    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }

  static calculateDualRSI(candles) {
    if (!candles || candles.length < 15) return { rsiFast: 50, rsiStandard: 50, score: 0, condition: 'NEUTRAL' };
    const closes = candles.map(c => c.close);
    const rsiFast = this.calculateRSI(closes, 7);
    const rsiStandard = this.calculateRSI(closes, 14);
    let score = 0, condition = 'NEUTRAL';

    if (rsiFast > 65 && rsiStandard > 55) {
      score = 1.0; condition = 'BULLISH_EXPANSION';
    } else if (rsiFast < 35 && rsiStandard < 45) {
      score = -1.0; condition = 'BEARISH_EXPANSION';
    } else if (rsiFast > 80) {
      score = -0.3; condition = 'OVERBOUGHT_EXHAUSTION';
    } else if (rsiFast < 20) {
      score = 0.3; condition = 'OVERSOLD_EXHAUSTION';
    } else if (rsiFast > 52 && rsiStandard > 50) {
      score = 0.4; condition = 'MILD_BULLISH';
    } else if (rsiFast < 48 && rsiStandard < 50) {
      score = -0.4; condition = 'MILD_BEARISH';
    }

    return {
      rsiFast: parseFloat(rsiFast.toFixed(1)),
      rsiStandard: parseFloat(rsiStandard.toFixed(1)),
      score,
      condition
    };
  }

  // 6. Stochastic (5, 3, 3)
  static calculateStochastic(candles, kPeriod = 5, dPeriod = 3, smooth = 3) {
    if (!candles || candles.length < kPeriod + dPeriod + smooth) {
      return { k: 50, d: 50, score: 0, state: 'NEUTRAL' };
    }
    const rawKList = [];
    for (let i = candles.length - (dPeriod + smooth + 2); i < candles.length; i++) {
      if (i < kPeriod - 1) continue;
      const slice = candles.slice(i - kPeriod + 1, i + 1);
      const lowestLow = Math.min(...slice.map(c => c.low));
      const highestHigh = Math.max(...slice.map(c => c.high));
      const close = candles[i].close;
      const denom = (highestHigh - lowestLow);
      rawKList.push(denom !== 0 ? ((close - lowestLow) / denom) * 100 : 50);
    }
    const smoothK = this.calculateSMA(rawKList, smooth);
    const d = this.calculateSMA(rawKList, dPeriod);
    let score = 0, state = 'NEUTRAL';
    if (smoothK > d && smoothK < 80) { score = 0.8; state = 'BULLISH_CROSS'; }
    else if (smoothK < d && smoothK > 20) { score = -0.8; state = 'BEARISH_CROSS'; }
    else if (smoothK >= 80) { score = smoothK < d ? -0.7 : 0.2; state = 'OVERBOUGHT'; }
    else if (smoothK <= 20) { score = smoothK > d ? 0.7 : -0.2; state = 'OVERSOLD'; }

    return { k: parseFloat(smoothK.toFixed(1)), d: parseFloat(d.toFixed(1)), score, state };
  }

  // 7. MACD (12, 26, 9)
  static calculateMACD(candles) {
    if (!candles || candles.length < 28) return { macd: 0, signal: 0, histogram: 0, score: 0, trend: 'NEUTRAL' };
    const closes = candles.map(c => c.close);
    const fastEMA = this.calculateEMASeries(closes, 12);
    const slowEMA = this.calculateEMASeries(closes, 26);
    const macdLineSeries = [];
    for (let i = 0; i < closes.length; i++) {
      macdLineSeries.push(fastEMA[i] - slowEMA[i]);
    }
    const signalSeries = this.calculateEMASeries(macdLineSeries, 9);
    const currMACD = macdLineSeries[macdLineSeries.length - 1];
    const currSignal = signalSeries[signalSeries.length - 1];
    const prevMACD = macdLineSeries[macdLineSeries.length - 2] || currMACD;
    const prevSignal = signalSeries[signalSeries.length - 2] || currSignal;
    const currHistogram = currMACD - currSignal;
    const prevHistogram = prevMACD - prevSignal;
    const isAccelerating = Math.abs(currHistogram) > Math.abs(prevHistogram);

    let score = 0, trend = 'NEUTRAL';
    if (currMACD > currSignal && currHistogram > 0) {
      score = isAccelerating ? 1.0 : 0.6; trend = 'BULLISH_EXPANSION';
    } else if (currMACD < currSignal && currHistogram < 0) {
      score = isAccelerating ? -1.0 : -0.6; trend = 'BEARISH_EXPANSION';
    }

    return {
      macd: parseFloat(currMACD.toFixed(2)),
      signal: parseFloat(currSignal.toFixed(2)),
      histogram: parseFloat(currHistogram.toFixed(2)),
      score,
      trend
    };
  }

  // 8. CCI (14)
  static calculateCCI(candles, period = 14) {
    if (!candles || candles.length < period) return { cci: 0, score: 0 };
    const subset = candles.slice(-period);
    const typicalPrices = subset.map(c => (c.high + c.low + c.close) / 3);
    const meanTP = this.calculateSMA(typicalPrices, period);
    let meanDeviation = 0;
    for (let i = 0; i < typicalPrices.length; i++) {
      meanDeviation += Math.abs(typicalPrices[i] - meanTP);
    }
    meanDeviation = meanDeviation / period;
    const currentTP = typicalPrices[typicalPrices.length - 1];
    const cci = meanDeviation !== 0 ? (currentTP - meanTP) / (0.015 * meanDeviation) : 0;
    let score = 0;
    if (cci > 100) score = 0.8;
    else if (cci > 0) score = 0.4;
    else if (cci < -100) score = -0.8;
    else if (cci < 0) score = -0.4;

    return { cci: parseFloat(cci.toFixed(1)), score };
  }

  // 9. Williams %R (14)
  static calculateWilliamsR(candles, period = 14) {
    if (!candles || candles.length < period) return { wr: -50, score: 0 };
    const subset = candles.slice(-period);
    const highestHigh = Math.max(...subset.map(c => c.high));
    const lowestLow = Math.min(...subset.map(c => c.low));
    const close = subset[subset.length - 1].close;
    const denom = highestHigh - lowestLow;
    const wr = denom !== 0 ? ((highestHigh - close) / denom) * -100 : -50;
    let score = 0;
    if (wr > -20) score = -0.5;
    else if (wr < -80) score = 0.5;
    else if (wr > -50) score = 0.5;
    else score = -0.5;

    return { wr: parseFloat(wr.toFixed(1)), score };
  }

  // 12. ATR (14)
  static calculateATR(candles, period = 14) {
    if (!candles || candles.length < 2) return 25.0;
    const p = Math.min(period, candles.length - 1);
    let sumTR = 0;
    for (let i = candles.length - p; i < candles.length; i++) {
      const c = candles[i];
      const prev = candles[i - 1];
      const tr = Math.max(
        c.high - c.low,
        Math.abs(c.high - prev.close),
        Math.abs(c.low - prev.close)
      );
      sumTR += tr;
    }
    return sumTR / p;
  }

  // 10. Bollinger Bands (20, 2)
  static calculateBollingerBands(candles, period = 20, multiplier = 2.0) {
    if (!candles || candles.length < period) {
      const cp = candles && candles.length > 0 ? candles[candles.length - 1].close : 75000;
      return { upper: cp + 50, middle: cp, lower: cp - 50, percentB: 0.5, isSqueeze: false, score: 0 };
    }
    const closes = candles.map(c => c.close);
    const middle = this.calculateSMA(closes, period);
    const stdDev = this.calculateStandardDeviation(closes, period);
    const upper = middle + (multiplier * stdDev);
    const lower = middle - (multiplier * stdDev);
    const currentClose = closes[closes.length - 1];
    const bandWidth = upper - lower;
    const percentB = bandWidth !== 0 ? (currentClose - lower) / bandWidth : 0.5;
    const isSqueeze = (bandWidth / middle) < 0.0025;
    let score = 0;
    if (percentB > 0.8) score = 0.8;
    else if (percentB < 0.2) score = -0.8;
    else if (percentB > 0.5) score = 0.4;
    else score = -0.4;

    return {
      upper: parseFloat(upper.toFixed(2)),
      middle: parseFloat(middle.toFixed(2)),
      lower: parseFloat(lower.toFixed(2)),
      percentB: parseFloat(percentB.toFixed(3)),
      isSqueeze,
      score
    };
  }

  // 11. Keltner Channel (20, 1.5 ATR)
  static calculateKeltnerChannel(candles, period = 20, multiplier = 1.5) {
    if (!candles || candles.length < period) return { upper: 0, lower: 0, middle: 0, score: 0 };
    const closes = candles.map(c => c.close);
    const middle = this.calculateEMA(closes, period);
    const atr = this.calculateATR(candles, period);
    const upper = middle + (multiplier * atr);
    const lower = middle - (multiplier * atr);
    const currentClose = closes[closes.length - 1];
    let score = 0;
    if (currentClose > upper) score = 1.0;
    else if (currentClose < lower) score = -1.0;
    else if (currentClose > middle) score = 0.4;
    else score = -0.4;

    return {
      upper: parseFloat(upper.toFixed(2)),
      lower: parseFloat(lower.toFixed(2)),
      middle: parseFloat(middle.toFixed(2)),
      score
    };
  }

  // 13. Candlestick Geometry
  static calculateCandlestickGeometry(candles) {
    if (!candles || candles.length === 0) return { pattern: 'INSUFFICIENT_DATA', score: 0 };
    const current = candles[candles.length - 1];
    const prev = candles.length > 1 ? candles[candles.length - 2] : null;
    const range = Math.max(0.1, current.high - current.low);
    const upperWick = current.high - Math.max(current.close, current.open);
    const lowerWick = Math.min(current.close, current.open) - current.low;
    const isGreen = current.close >= current.open;

    let score = 0;
    let pattern = isGreen ? 'BULLISH_BODY' : 'BEARISH_BODY';

    if (lowerWick / range >= 0.6) {
      score = 1.0; pattern = 'BULLISH_HAMMER_PINBAR';
    } else if (upperWick / range >= 0.6) {
      score = -1.0; pattern = 'BEARISH_SHOOTING_STAR';
    } else if (prev && prev.close < prev.open && isGreen && current.close > prev.open && current.open < prev.close) {
      score = 0.9; pattern = 'BULLISH_ENGULFING';
    } else if (prev && prev.close > prev.open && !isGreen && current.close < prev.open && current.open > prev.close) {
      score = -0.9; pattern = 'BEARISH_ENGULFING';
    } else {
      score = isGreen ? 0.3 : -0.3;
    }

    return {
      pattern,
      score,
      upperWickPct: parseFloat(((upperWick / range) * 100).toFixed(1)),
      lowerWickPct: parseFloat(((lowerWick / range) * 100).toFixed(1))
    };
  }

  // 14. Real-Time Volume Delta & CVD
  static calculateVolumeDelta(trades) {
    if (!trades || trades.length === 0) return { buyVol: 0, sellVol: 0, delta: 0, buyRatio: 50.0, score: 0 };
    let buyVol = 0, sellVol = 0;
    for (let i = 0; i < trades.length; i++) {
      const t = trades[i];
      if (t.isBuyerMaker) sellVol += t.qty;
      else buyVol += t.qty;
    }
    const totalVol = buyVol + sellVol;
    const delta = buyVol - sellVol;
    const ratio = totalVol > 0 ? (buyVol / totalVol) * 100 : 50;
    let score = 0;
    if (ratio >= 65) score = 1.0;
    else if (ratio <= 35) score = -1.0;
    else if (ratio > 52) score = 0.4;
    else if (ratio < 48) score = -0.4;

    return {
      buyVol: parseFloat(buyVol.toFixed(3)),
      sellVol: parseFloat(sellVol.toFixed(3)),
      delta: parseFloat(delta.toFixed(3)),
      buyRatio: parseFloat(ratio.toFixed(1)),
      score
    };
  }

  // 15 & 16. Strike Delta & Late-Round Oracle Sniper
  static calculateStrikeDeltaAndSniper({ strikePrice, currentPrice, secondsRemaining, atr = 25 }) {
    if (!strikePrice || strikePrice <= 0 || !currentPrice || currentPrice <= 0) {
      return {
        strikeDelta: 0,
        strikeDeltaBps: 0,
        isSnipeWindow: false,
        sniperConfidence: 50,
        sniperDirection: 'HOLD',
        score: 0,
        message: 'Awaiting round synchronization'
      };
    }
    const delta = currentPrice - strikePrice;
    const deltaBps = (delta / strikePrice) * 10000;
    const isLateRound = secondsRemaining <= 65 && secondsRemaining >= 5;
    const isUltraLate = secondsRemaining <= 35 && secondsRemaining >= 5;
    const minEdge = Math.max(10, atr * 0.35);

    let isSnipeWindow = false;
    let sniperConfidence = 50;
    let sniperDirection = delta >= 0 ? 'UP' : 'DOWN';
    let score = 0;
    let message = '';

    if (isLateRound) {
      isSnipeWindow = true;
      const absDelta = Math.abs(delta);
      if (absDelta >= minEdge) {
        sniperDirection = delta > 0 ? 'UP' : 'DOWN';
        const baseConf = isUltraLate ? 90 : 82;
        const edgeBonus = Math.min(8, Math.floor((absDelta / minEdge) * 3));
        sniperConfidence = Math.min(98, baseConf + edgeBonus);
        score = delta > 0 ? 1.0 : -1.0;
        message = delta > 0
          ? ('SNIPER ACTIVE: Spot +$' + delta.toFixed(1) + ' above strike with ' + secondsRemaining + 's left! 90%+ probability of closing UP.')
          : ('SNIPER ACTIVE: Spot -$' + Math.abs(delta).toFixed(1) + ' below strike with ' + secondsRemaining + 's left! 90%+ probability of closing DOWN.');
      } else {
        sniperConfidence = 62;
        score = delta > 0 ? 0.2 : -0.2;
        message = 'TIGHT STRIKE ZONE (Δ $' + delta.toFixed(1) + '). Noise risk — wait for clean break.';
      }
    } else {
      const remainingSecs = secondsRemaining % 60;
      message = 'Round Active (' + Math.floor(secondsRemaining / 60) + 'm ' + remainingSecs + 's left). Confluence accumulating.';
      score = delta > 0 ? 0.4 : -0.4;
      sniperConfidence = 68;
    }

    return {
      strikeDelta: parseFloat(delta.toFixed(2)),
      strikeDeltaBps: parseFloat(deltaBps.toFixed(1)),
      isSnipeWindow,
      sniperConfidence,
      sniperDirection,
      score,
      message
    };
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { IndicatorSuite };
}
if (typeof window !== 'undefined') {
  window.IndicatorSuite = IndicatorSuite;
}
if (typeof globalThis !== 'undefined') {
  globalThis.IndicatorSuite = IndicatorSuite;
}
