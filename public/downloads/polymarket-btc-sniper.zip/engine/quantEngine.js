/**
 * Polymarket BTC 5-Minute Prediction Engine
 * Institutional Quant & Sniper Engine
 * 
 * Synthesizes the 16-pillar indicator suite into real-time actionable signals,
 * tracks 5-minute epoch rounds, computes strike distance, and flags
 * Polymarket odds mispricings.
 */

class QuantEngine {
  constructor() {
    this.roundDurationSec = 300; // 5 Minutes
    this.minSniperConfidence = 85;
  }

  /**
   * Main analysis execution on each price tick / kline update
   */
  analyzeRound({ candles1m, currentPrice, strikePrice, trades = [], polymarketOdds = null, serverTimeSec = null }) {
    const nowSec = serverTimeSec || Math.floor(Date.now() / 1000);
    const roundStartSec = nowSec - (nowSec % this.roundDurationSec);
    const roundEndSec = roundStartSec + this.roundDurationSec;
    const secondsRemaining = Math.max(1, roundEndSec - nowSec);
    const elapsedSec = this.roundDurationSec - secondsRemaining;

    // Use currentPrice as strike fallback if uninitialized
    const effectiveStrike = (strikePrice && strikePrice > 0) ? strikePrice : currentPrice;

    // Determine round phase
    let phase = 'ACCUMULATION';
    if (elapsedSec < 35) {
      phase = 'OPENING_LOCK';
    } else if (secondsRemaining <= 65 && secondsRemaining >= 5) {
      phase = 'SNIPER_WINDOW';
    } else if (secondsRemaining < 5) {
      phase = 'SETTLEMENT';
    } else if (elapsedSec >= 35 && elapsedSec < 180) {
      phase = 'ACCUMULATION';
    } else {
      phase = 'MOMENTUM_EXPANSION';
    }

    // 1. Evaluate Cluster A: Trend & Momentum Expansion
    const emaRibbon = IndicatorSuite.calculateEMARibbon(candles1m);
    const superTrend = IndicatorSuite.calculateSuperTrend(candles1m, 10, 3.0);
    const adxData = IndicatorSuite.calculateADX(candles1m, 14);
    const linReg = IndicatorSuite.calculateLinearRegression(candles1m, 14);

    // 2. Evaluate Cluster B: Momentum Oscillators & Cycle Exhaustion
    const dualRsi = IndicatorSuite.calculateDualRSI(candles1m);
    const stoch = IndicatorSuite.calculateStochastic(candles1m, 5, 3, 3);
    const macdData = IndicatorSuite.calculateMACD(candles1m);
    const cciData = IndicatorSuite.calculateCCI(candles1m, 14);
    const wrData = IndicatorSuite.calculateWilliamsR(candles1m, 14);

    // 3. Evaluate Cluster C: Volatility, Channels & Squeeze
    const atrValue = IndicatorSuite.calculateATR(candles1m, 14);
    const bbData = IndicatorSuite.calculateBollingerBands(candles1m, 20, 2.0);
    const keltner = IndicatorSuite.calculateKeltnerChannel(candles1m, 20, 1.5);

    // 4. Evaluate Cluster D: Price Action & Order Flow
    const candleGeo = IndicatorSuite.calculateCandlestickGeometry(candles1m);
    const volDelta = IndicatorSuite.calculateVolumeDelta(trades);

    // 5. Evaluate Cluster E: Strike Delta & Late-Round Oracle Sniper
    const strikeAnalysis = IndicatorSuite.calculateStrikeDeltaAndSniper({
      strikePrice: effectiveStrike,
      currentPrice,
      secondsRemaining,
      atr: atrValue
    });

    // Weighted Cluster Aggregations (-1.0 to +1.0)
    const trendScore = (emaRibbon.score * 0.35) + (superTrend.score * 0.35) + (linReg.score * 0.2) + (adxData.score * 0.1);
    const oscScore = (dualRsi.score * 0.25) + (macdData.score * 0.3) + (stoch.score * 0.2) + (cciData.score * 0.15) + (wrData.score * 0.1);
    const volScore = (bbData.score * 0.5) + (keltner.score * 0.5);
    const flowScore = (candleGeo.score * 0.4) + (volDelta.score * 0.6);
    const sniperScore = (strikeAnalysis.score * 0.6) + (volDelta.score * 0.4);

    // Phase-Adaptive Master Weighting
    let wTrend = 0.30;
    let wOsc = 0.25;
    let wVol = 0.15;
    let wFlow = 0.15;
    let wStrike = 0.15;

    if (phase === 'OPENING_LOCK') {
      // Early in candle: focus on macro trend and oscillators
      wTrend = 0.40; wOsc = 0.30; wVol = 0.15; wFlow = 0.10; wStrike = 0.05;
    } else if (phase === 'MOMENTUM_EXPANSION') {
      // Middle of round: momentum, strike delta & flow
      wTrend = 0.25; wOsc = 0.20; wVol = 0.15; wFlow = 0.20; wStrike = 0.20;
    } else if (phase === 'SNIPER_WINDOW') {
      // Final 60 seconds: Strike delta & spot drift are dominant (75%+)
      wTrend = 0.10; wOsc = 0.05; wVol = 0.05; wFlow = 0.15; wStrike = 0.65;
    }

    const composite = (trendScore * wTrend) +
                      (oscScore * wOsc) +
                      (volScore * wVol) +
                      (flowScore * wFlow) +
                      (strikeAnalysis.score * wStrike);

    // Normalize to -100 to +100
    const compositeScore = parseFloat((composite * 100).toFixed(1));

    // Direction & Confidence Calculation
    let prediction = 'NEUTRAL';
    let baseConfidence = 50;

    if (compositeScore >= 18) {
      prediction = 'UP';
      baseConfidence = 60 + Math.min(38, Math.floor(Math.abs(compositeScore) * 0.45));
    } else if (compositeScore <= -18) {
      prediction = 'DOWN';
      baseConfidence = 60 + Math.min(38, Math.floor(Math.abs(compositeScore) * 0.45));
    } else {
      prediction = strikeAnalysis.strikeDelta >= 0 ? 'UP' : 'DOWN';
      baseConfidence = 55;
    }

    // In Sniper Window, override confidence if oracle drift edge is high
    let confidence = baseConfidence;
    if (phase === 'SNIPER_WINDOW') {
      if (strikeAnalysis.isSnipeWindow && strikeAnalysis.sniperConfidence > confidence) {
        confidence = strikeAnalysis.sniperConfidence;
        prediction = strikeAnalysis.sniperDirection;
      }
    }

    // Action Label & Color
    let action = 'WAIT_NO_EDGE';
    let actionLabel = 'EVALUATING CONFLUENCE';
    let actionSubtitle = 'Analyzing 16 technical indicators across 5 clusters';
    let actionColor = '#8e9aa8'; // Neutral grey

    if (phase === 'SNIPER_WINDOW' && confidence >= 85) {
      if (prediction === 'UP') {
        action = 'SNIPER_BUY_YES';
        actionLabel = 'SNIPER ACTIVE: CALL UP (YES)';
        actionSubtitle = strikeAnalysis.message;
        actionColor = '#00ff88'; // Bright Neon Green
      } else {
        action = 'SNIPER_BUY_NO';
        actionLabel = 'SNIPER ACTIVE: PUT DOWN (NO)';
        actionSubtitle = strikeAnalysis.message;
        actionColor = '#ff3366'; // Hot Neon Pink/Red
      }
    } else if (confidence >= 80) {
      if (prediction === 'UP') {
        action = 'STRONG_UP';
        actionLabel = 'HIGH CONVICTION: CALL UP';
        actionSubtitle = 'Multi-cluster bullish alignment across Trend, RSI & CVD';
        actionColor = '#00e676';
      } else {
        action = 'STRONG_DOWN';
        actionLabel = 'HIGH CONVICTION: PUT DOWN';
        actionSubtitle = 'Multi-cluster bearish breakdown across Trend, MACD & CVD';
        actionColor = '#ff1744';
      }
    } else if (confidence >= 68) {
      if (prediction === 'UP') {
        action = 'MODERATE_UP';
        actionLabel = 'MODERATE BIAS: UP';
        actionSubtitle = 'Bullish pressure present; waiting for sniper confirmation';
        actionColor = '#29b6f6';
      } else {
        action = 'MODERATE_DOWN';
        actionLabel = 'MODERATE BIAS: DOWN';
        actionSubtitle = 'Bearish pressure present; waiting for sniper confirmation';
        actionColor = '#ff9100';
      }
    } else {
      action = 'CHOP_WAIT';
      actionLabel = 'CONSOLIDATION / NO EDGE';
      actionSubtitle = 'Strike delta within noise band. Hold positions.';
      actionColor = '#ffb300';
    }

    // Polymarket Odds Arbitrage & Mispricing Model
    let polymarketEdge = null;
    if (polymarketOdds && polymarketOdds.yesPrice !== undefined) {
      const fairYesOdds = parseFloat((confidence / 100).toFixed(2));
      const marketYesOdds = parseFloat(Number(polymarketOdds.yesPrice).toFixed(2));
      const edge = fairYesOdds - marketYesOdds;

      let mispricingType = 'FAIRLY_PRICED';
      if (prediction === 'UP' && edge >= 0.12) {
        mispricingType = 'UNDERPRICED_YES';
      } else if (prediction === 'DOWN' && (marketYesOdds - (1 - fairYesOdds)) >= 0.12) {
        mispricingType = 'OVERPRICED_YES_BUY_NO';
      }

      polymarketEdge = {
        fairYesOdds,
        marketYesOdds,
        edgePct: parseFloat((edge * 100).toFixed(1)),
        mispricingType
      };
    }

    return {
      roundId: '5M_' + new Date(roundStartSec * 1000).toISOString().slice(11, 16).replace(':', ''),
      roundStartSec,
      roundEndSec,
      secondsRemaining,
      phase,
      currentPrice: parseFloat(currentPrice.toFixed(2)),
      strikePrice: parseFloat(effectiveStrike.toFixed(2)),
      strikeDelta: strikeAnalysis.strikeDelta,
      strikeDeltaBps: strikeAnalysis.strikeDeltaBps,
      compositeScore,
      prediction,
      confidence,
      action,
      actionLabel,
      actionSubtitle,
      actionColor,
      isSniperActive: phase === 'SNIPER_WINDOW' && confidence >= 85,
      polymarketEdge,
      clusterDetails: {
        trend: {
          score: parseFloat((trendScore * 100).toFixed(1)),
          emaAlignment: emaRibbon.alignment,
          superTrend: superTrend.trend,
          adx: adxData.adx,
          adxTrending: adxData.isTrending,
          regressionSlope: linReg.slope
        },
        oscillators: {
          score: parseFloat((oscScore * 100).toFixed(1)),
          rsiFast: dualRsi.rsiFast,
          rsiStandard: dualRsi.rsiStandard,
          rsiCondition: dualRsi.condition,
          stochState: stoch.state,
          macdTrend: macdData.trend,
          cci: cciData.cci
        },
        volatility: {
          score: parseFloat((volScore * 100).toFixed(1)),
          atr: parseFloat(atrValue.toFixed(1)),
          bbPercentB: bbData.percentB,
          bbSqueeze: bbData.isSqueeze
        },
        orderFlow: {
          score: parseFloat((flowScore * 100).toFixed(1)),
          candlePattern: candleGeo.pattern,
          buyRatio: volDelta.buyRatio,
          volumeDelta: volDelta.delta
        },
        sniper: {
          score: parseFloat((sniperScore * 100).toFixed(1)),
          isSnipeWindow: strikeAnalysis.isSnipeWindow,
          confidence: strikeAnalysis.sniperConfidence,
          message: strikeAnalysis.message
        }
      }
    };
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { QuantEngine };
}
if (typeof window !== 'undefined') {
  window.QuantEngine = QuantEngine;
}
if (typeof globalThis !== 'undefined') {
  globalThis.QuantEngine = QuantEngine;
}
