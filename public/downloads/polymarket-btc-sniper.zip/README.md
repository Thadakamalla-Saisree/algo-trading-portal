# Polymarket BTC 5-Minute Live Predictor & Sniper Extension

A high-accuracy, institutional-grade Chrome Extension (Manifest V3) that predicts and acts live on Polymarket 5-Minute Bitcoin prediction markets using a 16-pillar multi-cluster quantitative confluence engine and a Late-Round Oracle Drift Sniper.

## Features
- Live low-latency Binance WebSocket feed (<50ms)
- 16-Pillar Indicator Suite (Quad EMA, SuperTrend, ADX, LinReg, Dual RSI, Stochastic, MACD, CCI, Williams %R, Bollinger Bands, Keltner, ATR, Candlestick Geometry, Volume Delta CVD, Strike Delta, Late-Round Sniper)
- Automatic 5-minute round synchronization with Strike Lock
- Polymarket live odds ingestion and mispricing arbitrage alerts
- Injected floating HUD on polymarket.com with 1-click execution guide
- Standalone extension popup dashboard with session win-rate tracker and audio alerts

## Installation Guide
1. Open Chrome and go to chrome://extensions
2. Turn ON Developer mode (top right)
3. Click Load unpacked and select this folder: E:/Antigravity/projects/polymarket-btc-5m-sniper-extension
4. Visit https://polymarket.com to see the live HUD, or click the extension icon to view the popup dashboard!
