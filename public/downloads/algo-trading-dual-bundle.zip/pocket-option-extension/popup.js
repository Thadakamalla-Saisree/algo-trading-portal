/**
 * Pocket Signal Pro — Popup Script
 */
document.addEventListener('DOMContentLoaded', async () => {
  console.log('Pocket Signal Pro popup active');
});
