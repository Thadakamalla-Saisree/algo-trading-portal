/**
 * Pocket Signal Pro — 12-Pillar Institutional Quantitative Confluence Engine (v2.0.0)
 * 
 * Engineered specifically for 1-Minute Binary Options (Pocket Option / OTC & Live Markets).
 * Synthesizes 12 independent quantitative dimensions across 4 core market clusters:
 * 
 * CLUSTER A: TREND & MOMENTUM EXPANSION
 * 1. Quad EMA Ribbon (EMA 3, 8, 21, 50) & Ribbon Alignment
 * 2. SuperTrend (10, 3.0 ATR) Dynamic Trailing Stop
 * 3. ADX (14) & DMI (+DI / -DI) Institutional Trend Strength Engine
 * 
 * CLUSTER B: MOMENTUM OSCILLATORS & CYCLE FILTERS
 * 4. Dual Wilder-Smoothed RSI (Fast RSI 7 & Standard RSI 14) with Neutral Deadzone
 * 5. Full Stochastic Oscillator (5, 3, 3) Extreme Zone Crossovers
 * 6. True MACD (12, 26, 9) with Exponential Signal & Histogram Acceleration
 * 7. Commodity Channel Index (CCI 14) Mean Reversion & Zero-Cross
 * 8. Williams %R (14) Momentum Extreme Exhaustion
 * 
 * CLUSTER C: VOLATILITY, CHANNELS & SQUEEZE
 * 9. Bollinger Bands (20, 2) & %B Squeeze / Band-Walking
 * 10. Keltner Channel (20, 1.5 ATR) Volatility Breakout & Compression
 * 
 * CLUSTER D: MARKET STRUCTURE & PRICE ACTION GEOMETRY
 * 11. Market Structure (Swing Highs/Lows, Dynamic Support/Resistance & HH/HL)
 * 12. Candlestick Wick Geometry & Canvas Ground Truth (Pin-Bars, Engulfing, Regression Slope)
 */
(function() {
  'use strict';

  // =========================================================================
  // 1. MATHEMATICAL CORE & EMA CALCULATIONS
  // =========================================================================

  function calculateEMASeries(values, period) {
    if (!values || values.length === 0) return [];
    const p = Math.max(2, Math.min(period, values.length));
    const k = 2 / (p + 1);
    const series = new Array(values.length);

    let sum = 0;
    const seedLen = Math.min(p, values.length);
    for (let i = 0; i < seedLen; i++) {
      sum += values[i];
      series[i] = sum / (i + 1);
    }

    for (let i = seedLen; i < values.length; i++) {
      series[i] = (values[i] * k) + (series[i - 1] * (1 - k));
    }
    return series;
  }

  function calculateEMA(values, period) {
    const series = calculateEMASeries(values, period);
    return series.length > 0 ? series[series.length - 1] : 0;
  }

  function calculateSMA(values, period) {
    if (!values || values.length === 0) return 0;
    const p = Math.min(period, values.length);
    const slice = values.slice(-p);
    return slice.reduce((a, b) => a + b, 0) / p;
  }

  // =========================================================================
  // 2. AVERAGE TRUE RANGE (ATR 10 / 14)
  // =========================================================================

  function calculateATR(candles, period = 10) {
    if (!candles || candles.length < 2) return 0.0002;
    const trList = [];
    for (let i = 1; i < candles.length; i++) {
      const c = candles[i];
      const prev = candles[i - 1];
      const h = c.high !== undefined ? c.high : Math.max(c.open, c.close);
      const l = c.low !== undefined ? c.low : Math.min(c.open, c.close);
      const tr1 = h - l;
      const tr2 = Math.abs(h - prev.close);
      const tr3 = Math.abs(l - prev.close);
      trList.push(Math.max(tr1, tr2, tr3));
    }
    const p = Math.min(period, trList.length);
    let atr = trList.slice(0, p).reduce((a, b) => a + b, 0) / p;
    for (let i = p; i < trList.length; i++) {
      atr = (atr * (p - 1) + trList[i]) / p;
    }
    return Math.max(0.00001, atr);
  }

  // =========================================================================
  // 3. SUPERTREND (10, 3.0 ATR)
  // =========================================================================

  function calculateSuperTrend(candles, period = 10, multiplier = 3.0) {
    if (!candles || candles.length < 2) {
      return { trend: 'PUT', superTrend: 0, score: -2.0 };
    }
    const atr = calculateATR(candles, period);
    const n = candles.length;
    let inUptrend = true;
    let prevUpper = 0;
    let prevLower = 0;
    let superTrend = 0;

    for (let i = 0; i < n; i++) {
      const c = candles[i];
      const h = c.high !== undefined ? c.high : Math.max(c.open, c.close);
      const l = c.low !== undefined ? c.low : Math.min(c.open, c.close);
      const hl2 = (h + l) / 2;
      const basicUpper = hl2 + (multiplier * atr);
      const basicLower = hl2 - (multiplier * atr);

      if (i === 0) {
        prevUpper = basicUpper;
        prevLower = basicLower;
        inUptrend = c.close >= c.open;
        superTrend = inUptrend ? prevLower : prevUpper;
        continue;
      }

      const prevClose = candles[i - 1].close;
      const finalUpper = (basicUpper < prevUpper || prevClose > prevUpper) ? basicUpper : prevUpper;
      const finalLower = (basicLower > prevLower || prevClose < prevLower) ? basicLower : prevLower;

      if (inUptrend) {
        if (c.close < finalLower) {
          inUptrend = false;
          superTrend = finalUpper;
        } else {
          superTrend = finalLower;
        }
      } else {
        if (c.close > finalUpper) {
          inUptrend = true;
          superTrend = finalLower;
        } else {
          superTrend = finalUpper;
        }
      }

      prevUpper = finalUpper;
      prevLower = finalLower;
    }

    const trend = inUptrend ? 'CALL' : 'PUT';
    return {
      trend,
      superTrend: Number(superTrend.toFixed(5)),
      upperBand: Number(prevUpper.toFixed(5)),
      lowerBand: Number(prevLower.toFixed(5)),
      score: inUptrend ? 3.5 : -3.5
    };
  }

  // =========================================================================
  // 4. ADX (14) & DMI (+DI / -DI)
  // =========================================================================

  function calculateADX(candles, period = 14) {
    if (!candles || candles.length < 3) {
      return { adx: 20, pdi: 20, mdi: 20, isTrending: false, trendDirection: 'NEUTRAL', score: 0 };
    }
    const p = Math.min(period, candles.length - 1);
    const trList = [];
    const plusDM = [];
    const minusDM = [];

    for (let i = 1; i < candles.length; i++) {
      const c = candles[i];
      const prev = candles[i - 1];
      const h = c.high !== undefined ? c.high : Math.max(c.open, c.close);
      const l = c.low !== undefined ? c.low : Math.min(c.open, c.close);
      const prevH = prev.high !== undefined ? prev.high : Math.max(prev.open, prev.close);
      const prevL = prev.low !== undefined ? prev.low : Math.min(prev.open, prev.close);

      const tr = Math.max(h - l, Math.abs(h - prev.close), Math.abs(l - prev.close));
      trList.push(tr);

      const upMove = h - prevH;
      const downMove = prevL - l;

      plusDM.push((upMove > downMove && upMove > 0) ? upMove : 0);
      minusDM.push((downMove > upMove && downMove > 0) ? downMove : 0);
    }

    // Wilder smooth TR, +DM, -DM
    let smTR = trList.slice(0, p).reduce((a, b) => a + b, 0);
    let smPDM = plusDM.slice(0, p).reduce((a, b) => a + b, 0);
    let smMDM = minusDM.slice(0, p).reduce((a, b) => a + b, 0);

    const dxList = [];
    for (let i = p; i < trList.length; i++) {
      smTR = smTR - (smTR / p) + trList[i];
      smPDM = smPDM - (smPDM / p) + plusDM[i];
      smMDM = smMDM - (smMDM / p) + minusDM[i];

      const pdi = smTR > 0 ? (smPDM / smTR) * 100 : 0;
      const mdi = smTR > 0 ? (smMDM / smTR) * 100 : 0;
      const diSum = pdi + mdi;
      const dx = diSum > 0 ? (Math.abs(pdi - mdi) / diSum) * 100 : 0;
      dxList.push({ dx, pdi, mdi });
    }

    if (dxList.length === 0) {
      return { adx: 20, pdi: 20, mdi: 20, isTrending: false, trendDirection: 'NEUTRAL', score: 0 };
    }

    let adx = dxList[0].dx;
    for (let i = 1; i < dxList.length; i++) {
      adx = (adx * (p - 1) + dxList[i].dx) / p;
    }

    const last = dxList[dxList.length - 1];
    const isTrending = adx >= 22;
    const isBull = last.pdi > last.mdi;
    const score = isTrending ? (isBull ? 3.5 : -3.5) : (isBull ? 1.5 : -1.5);

    return {
      adx: Number(adx.toFixed(1)),
      pdi: Number(last.pdi.toFixed(1)),
      mdi: Number(last.mdi.toFixed(1)),
      isTrending,
      trendDirection: isBull ? 'CALL' : 'PUT',
      score
    };
  }

  // =========================================================================
  // 5. WILDER'S SMOOTHED RSI (7 & 14)
  // =========================================================================

  function calculateRSI(closes, period = 14) {
    if (!closes || closes.length < 2) return { current: 50.0, prev: 50.0, slope: 0 };
    const p = Math.max(2, Math.min(period, closes.length - 1));

    const changes = [];
    for (let i = 1; i < closes.length; i++) {
      changes.push(closes[i] - closes[i - 1]);
    }

    let avgGain = 0, avgLoss = 0;
    for (let i = 0; i < p; i++) {
      const chg = changes[i];
      if (chg >= 0) avgGain += chg;
      else avgLoss -= chg;
    }
    avgGain /= p;
    avgLoss /= p;

    let prevRSI = 50.0;
    let currRSI = 50.0;

    for (let i = p; i < changes.length; i++) {
      const chg = changes[i];
      const gain = chg >= 0 ? chg : 0;
      const loss = chg < 0 ? -chg : 0;

      avgGain = (avgGain * (p - 1) + gain) / p;
      avgLoss = (avgLoss * (p - 1) + loss) / p;

      prevRSI = currRSI;
      if (avgLoss === 0) currRSI = 100.0;
      else if (avgGain === 0) currRSI = 0.0;
      else {
        const rs = avgGain / avgLoss;
        currRSI = 100.0 - (100.0 / (1.0 + rs));
      }
    }

    return {
      current: Number(currRSI.toFixed(1)),
      prev: Number(prevRSI.toFixed(1)),
      slope: Number((currRSI - prevRSI).toFixed(2))
    };
  }

  // =========================================================================
  // 6. BOLLINGER BANDS (20, 2) & %B
  // =========================================================================

  function calculateBollingerBands(closes, period = 20, multiplier = 2) {
    if (!closes || closes.length < 2) {
      const last = closes && closes.length > 0 ? closes[closes.length - 1] : 1.0;
      return { middle: last, upper: last * 1.002, lower: last * 0.998, pb: 0.5, bandwidth: 0.004, isExpanding: false };
    }
    const p = Math.min(period, closes.length);
    const slice = closes.slice(-p);
    const sma = slice.reduce((a, b) => a + b, 0) / p;
    const variance = slice.reduce((sum, val) => sum + Math.pow(val - sma, 2), 0) / p;
    const stdDev = Math.sqrt(variance);
    const upper = sma + (multiplier * stdDev);
    const lower = sma - (multiplier * stdDev);
    const lastClose = closes[closes.length - 1];

    const bandRange = upper - lower;
    const pb = (bandRange <= 0) ? 0.5 : (lastClose - lower) / bandRange;
    const bandwidth = sma > 0 ? bandRange / sma : 0.004;

    let prevBandwidth = bandwidth;
    if (closes.length > p + 1) {
      const prevSlice = closes.slice(-(p + 1), -1);
      const prevSma = prevSlice.reduce((a, b) => a + b, 0) / p;
      const prevVar = prevSlice.reduce((sum, val) => sum + Math.pow(val - prevSma, 2), 0) / p;
      const prevDev = Math.sqrt(prevVar);
      prevBandwidth = prevSma > 0 ? (2 * multiplier * prevDev) / prevSma : bandwidth;
    }

    return { 
      middle: Number(sma.toFixed(6)), 
      upper: Number(upper.toFixed(6)), 
      lower: Number(lower.toFixed(6)), 
      pb: Number(pb.toFixed(3)),
      bandwidth: Number(bandwidth.toFixed(5)),
      isExpanding: bandwidth > prevBandwidth * 1.05
    };
  }

  // =========================================================================
  // 7. KELTNER CHANNEL (20, 1.5 ATR) & SQUEEZE BREAKOUT
  // =========================================================================

  function calculateKeltnerChannel(candles, closes, period = 20, multiplier = 1.5) {
    if (!closes || closes.length < 2) {
      return { upper: 0, lower: 0, inSqueeze: false };
    }
    const ema20 = calculateEMA(closes, period);
    const atr = calculateATR(candles, 10);
    const upper = ema20 + (multiplier * atr);
    const lower = ema20 - (multiplier * atr);

    const bb = calculateBollingerBands(closes, period, 2);
    // Bollinger Band inside Keltner Channel = Squeeze Compression
    const inSqueeze = (bb.upper < upper) && (bb.lower > lower);

    return {
      upper: Number(upper.toFixed(6)),
      lower: Number(lower.toFixed(6)),
      inSqueeze
    };
  }

  // =========================================================================
  // 8. FULL STOCHASTIC OSCILLATOR (5, 3, 3)
  // =========================================================================

  function calculateStochastic(candles, kPeriod = 5, dPeriod = 3, sPeriod = 3) {
    if (!candles || candles.length < 2) {
      return { k: 50.0, d: 50.0, prevK: 50.0, prevD: 50.0, cross: 'NONE' };
    }
    const rawKList = [];
    const minLookback = kPeriod;
    const totalBars = candles.length;

    for (let i = Math.max(0, totalBars - (dPeriod + sPeriod + 5)); i < totalBars; i++) {
      const windowSlice = candles.slice(Math.max(0, i - minLookback + 1), i + 1);
      if (windowSlice.length === 0) continue;
      const highest = Math.max(...windowSlice.map(c => c.high !== undefined ? c.high : c.close));
      const lowest = Math.min(...windowSlice.map(c => c.low !== undefined ? c.low : c.close));
      const currentClose = windowSlice[windowSlice.length - 1].close;

      let rawK = 50.0;
      if (highest !== lowest) {
        rawK = ((currentClose - lowest) / (highest - lowest)) * 100.0;
      }
      rawKList.push(rawK);
    }

    const smoothKList = [];
    for (let i = dPeriod - 1; i < rawKList.length; i++) {
      const slice = rawKList.slice(i - dPeriod + 1, i + 1);
      smoothKList.push(slice.reduce((a, b) => a + b, 0) / slice.length);
    }

    const smoothDList = [];
    for (let i = sPeriod - 1; i < smoothKList.length; i++) {
      const slice = smoothKList.slice(i - sPeriod + 1, i + 1);
      smoothDList.push(slice.reduce((a, b) => a + b, 0) / slice.length);
    }

    const currentK = smoothKList.length > 0 ? smoothKList[smoothKList.length - 1] : 50.0;
    const prevK = smoothKList.length > 1 ? smoothKList[smoothKList.length - 2] : currentK;
    const currentD = smoothDList.length > 0 ? smoothDList[smoothDList.length - 1] : currentK;
    const prevD = smoothDList.length > 1 ? smoothDList[smoothDList.length - 2] : currentD;

    let cross = 'NONE';
    if (prevK <= prevD && currentK > currentD) cross = 'BULLISH_CROSS';
    else if (prevK >= prevD && currentK < currentD) cross = 'BEARISH_CROSS';

    return { 
      k: Number(currentK.toFixed(1)), 
      d: Number(currentD.toFixed(1)), 
      prevK: Number(prevK.toFixed(1)),
      prevD: Number(prevD.toFixed(1)),
      cross 
    };
  }

  // =========================================================================
  // 9. TRUE MACD (12, 26, 9) WITH HISTOGRAM ACCELERATION
  // =========================================================================

  function calculateMACD(closes, fastP = 12, slowP = 26, signalP = 9) {
    if (!closes || closes.length < 3) {
      return { macd: 0, signal: 0, hist: 0, prevHist: 0, acceleration: 0 };
    }
    const fPeriod = Math.min(fastP, Math.max(2, Math.floor(closes.length / 2)));
    const sPeriod = Math.min(slowP, Math.max(fPeriod + 1, closes.length - 1));

    const fastSeries = calculateEMASeries(closes, fPeriod);
    const slowSeries = calculateEMASeries(closes, sPeriod);

    const macdSeries = new Array(closes.length);
    for (let i = 0; i < closes.length; i++) {
      macdSeries[i] = fastSeries[i] - slowSeries[i];
    }

    const sigPeriod = Math.min(signalP, Math.max(2, Math.floor(closes.length / 3)));
    const signalSeries = calculateEMASeries(macdSeries, sigPeriod);

    const currentMACD = macdSeries[macdSeries.length - 1];
    const currentSignal = signalSeries[signalSeries.length - 1];
    const currentHist = currentMACD - currentSignal;

    const prevMACD = macdSeries.length > 1 ? macdSeries[macdSeries.length - 2] : currentMACD;
    const prevSignal = signalSeries.length > 1 ? signalSeries[signalSeries.length - 2] : currentSignal;
    const prevHist = prevMACD - prevSignal;
    const acceleration = currentHist - prevHist;

    return {
      macd: Number(currentMACD.toFixed(6)),
      signal: Number(currentSignal.toFixed(6)),
      hist: Number(currentHist.toFixed(6)),
      prevHist: Number(prevHist.toFixed(6)),
      acceleration: Number(acceleration.toFixed(6))
    };
  }

  // =========================================================================
  // 10. COMMODITY CHANNEL INDEX (CCI 14)
  // =========================================================================

  function calculateCCI(candles, period = 14) {
    if (!candles || candles.length < 2) return { current: 0, vote: 'NEUTRAL', score: 0 };
    const p = Math.min(period, candles.length);
    const tpList = [];

    for (let i = candles.length - p; i < candles.length; i++) {
      const c = candles[i];
      const h = c.high !== undefined ? c.high : Math.max(c.open, c.close);
      const l = c.low !== undefined ? c.low : Math.min(c.open, c.close);
      tpList.push((h + l + c.close) / 3);
    }

    const smaTP = tpList.reduce((a, b) => a + b, 0) / p;
    const meanDev = tpList.reduce((sum, tp) => sum + Math.abs(tp - smaTP), 0) / p;
    const currentTP = tpList[tpList.length - 1];

    const cci = meanDev > 0 ? (currentTP - smaTP) / (0.015 * meanDev) : 0;
    const val = Number(cci.toFixed(1));

    const lastBar = candles[candles.length - 1];
    const isGreen = lastBar ? lastBar.close >= lastBar.open : false;

    let vote = 'NEUTRAL';
    let score = 0;
    if (val >= 100) {
      if (!isGreen) {
        vote = 'PUT'; // Overbought rejection
        score = -3.2;
      } else {
        vote = 'CALL'; // Bullish momentum drive
        score = 3.5;
      }
    } else if (val <= -100) {
      if (isGreen) {
        vote = 'CALL'; // Confirmed oversold bounce
        score = 3.2;
      } else {
        vote = 'PUT'; // Bearish waterfall momentum drive
        score = -3.5;
      }
    } else if (val > 25) {
      vote = 'CALL';
      score = 2.0;
    } else if (val < -25) {
      vote = 'PUT';
      score = -2.0;
    }

    return { current: val, vote, score };
  }

  // =========================================================================
  // 11. WILLIAMS %R (14)
  // =========================================================================

  function calculateWilliamsR(candles, period = 14) {
    if (!candles || candles.length < 2) return { current: -50, vote: 'NEUTRAL', score: 0 };
    const p = Math.min(period, candles.length);
    const slice = candles.slice(-p);

    const highestHigh = Math.max(...slice.map(c => c.high !== undefined ? c.high : c.close));
    const lowestLow = Math.min(...slice.map(c => c.low !== undefined ? c.low : c.close));
    const currentClose = slice[slice.length - 1].close;

    let wr = -50;
    if (highestHigh !== lowestLow) {
      wr = ((highestHigh - currentClose) / (highestHigh - lowestLow)) * -100;
    }
    const val = Number(wr.toFixed(1));

    const lastBar = candles[candles.length - 1];
    const isGreen = lastBar ? lastBar.close >= lastBar.open : false;

    let vote = 'NEUTRAL';
    let score = 0;
    if (val >= -20) {
      if (!isGreen) {
        vote = 'PUT'; // Overbought rejection
        score = -3.0;
      } else {
        vote = 'CALL'; // Strong bullish run
        score = 3.2;
      }
    } else if (val <= -80) {
      if (isGreen) {
        vote = 'CALL'; // Confirmed oversold bounce
        score = 3.0;
      } else {
        vote = 'PUT'; // Strong bearish waterfall
        score = -3.5;
      }
    } else if (val > -50) {
      vote = 'CALL';
      score = 2.0;
    } else {
      vote = 'PUT';
      score = -2.0;
    }

    return { current: val, vote, score };
  }

  // =========================================================================
  // 12. MARKET STRUCTURE & DYNAMIC SUPPORT / RESISTANCE
  // =========================================================================

  function analyzeMarketStructure(candles) {
    if (!candles || candles.length < 6) {
      return { trend: 'RANGE', levelType: 'NONE', vote: 'NEUTRAL', score: 0, text: 'Consolidating' };
    }

    const n = Math.min(30, candles.length);
    const slice = candles.slice(-n);

    // Find Swing Highs and Swing Lows
    const swingHighs = [];
    const swingLows = [];

    for (let i = 2; i < slice.length - 2; i++) {
      const h = slice[i].high !== undefined ? slice[i].high : Math.max(slice[i].open, slice[i].close);
      const prevH1 = slice[i - 1].high !== undefined ? slice[i - 1].high : Math.max(slice[i - 1].open, slice[i - 1].close);
      const prevH2 = slice[i - 2].high !== undefined ? slice[i - 2].high : Math.max(slice[i - 2].open, slice[i - 2].close);
      const nextH1 = slice[i + 1].high !== undefined ? slice[i + 1].high : Math.max(slice[i + 1].open, slice[i + 1].close);
      const nextH2 = slice[i + 2].high !== undefined ? slice[i + 2].high : Math.max(slice[i + 2].open, slice[i + 2].close);

      if (h > prevH1 && h > prevH2 && h > nextH1 && h > nextH2) {
        swingHighs.push({ price: h, index: i });
      }

      const l = slice[i].low !== undefined ? slice[i].low : Math.min(slice[i].open, slice[i].close);
      const prevL1 = slice[i - 1].low !== undefined ? slice[i - 1].low : Math.min(slice[i - 1].open, slice[i - 1].close);
      const prevL2 = slice[i - 2].low !== undefined ? slice[i - 2].low : Math.min(slice[i - 2].open, slice[i - 2].close);
      const nextL1 = slice[i + 1].low !== undefined ? slice[i + 1].low : Math.min(slice[i + 1].open, slice[i + 1].close);
      const nextL2 = slice[i + 2].low !== undefined ? slice[i + 2].low : Math.min(slice[i + 2].open, slice[i + 2].close);

      if (l < prevL1 && l < prevL2 && l < nextL1 && l < nextL2) {
        swingLows.push({ price: l, index: i });
      }
    }

    const currentClose = slice[slice.length - 1].close;
    let vote = 'NEUTRAL';
    let score = 0;
    let text = 'Market Flow';

    // Check if price is at a major swing low (Support) or swing high (Resistance)
    if (swingLows.length > 0) {
      const nearestLow = Math.min(...swingLows.map(s => s.price));
      if (Math.abs(currentClose - nearestLow) / currentClose < 0.0003) {
        vote = 'CALL';
        score = 3.5;
        text = 'Support Level Bounce';
      }
    }
    if (swingHighs.length > 0) {
      const nearestHigh = Math.max(...swingHighs.map(s => s.price));
      if (Math.abs(currentClose - nearestHigh) / currentClose < 0.0003) {
        vote = 'PUT';
        score = -3.5;
        text = 'Resistance Level Rejection';
      }
    }

    // Check Higher Highs / Higher Lows (Uptrend) vs Lower Highs / Lower Lows (Downtrend)
    if (vote === 'NEUTRAL' && swingHighs.length >= 2 && swingLows.length >= 2) {
      const lastHigh = swingHighs[swingHighs.length - 1].price;
      const prevHigh = swingHighs[swingHighs.length - 2].price;
      const lastLow = swingLows[swingLows.length - 1].price;
      const prevLow = swingLows[swingLows.length - 2].price;

      if (lastHigh > prevHigh && lastLow > prevLow) {
        vote = 'CALL';
        score = 2.5;
        text = 'Higher Highs & Higher Lows';
      } else if (lastHigh < prevHigh && lastLow < prevLow) {
        vote = 'PUT';
        score = -2.5;
        text = 'Lower Highs & Lower Lows';
      }
    }

    return { vote, score, text };
  }

  // =========================================================================
  // 13. CANDLESTICK WICK GEOMETRY & PRICE ACTION
  // =========================================================================

  function evaluatePriceAction(candles) {
    if (!candles || candles.length === 0) {
      return { vote: 'NEUTRAL', score: 0, pattern: 'Market Flow', reason: 'Insufficient Bars' };
    }
    const last = candles[candles.length - 1];
    const prev = candles.length >= 2 ? candles[candles.length - 2] : null;
    const prev2 = candles.length >= 3 ? candles[candles.length - 3] : null;

    const isLastGreen = last.close >= last.open;
    const body = Math.abs(last.close - last.open);
    const high = last.high !== undefined ? last.high : Math.max(last.open, last.close);
    const low = last.low !== undefined ? last.low : Math.min(last.open, last.close);
    const totalRange = Math.max(0.00001, high - low);

    const upperWick = high - Math.max(last.open, last.close);
    const lowerWick = Math.min(last.open, last.close) - low;

    // Pin-bars
    if (upperWick >= body * 1.8 && upperWick >= totalRange * 0.48 && upperWick > lowerWick * 1.8) {
      return { vote: 'PUT', score: -4.0, pattern: 'Shooting Star Rejection', reason: 'Upper Wick Price Rejection' };
    }
    if (lowerWick >= body * 1.8 && lowerWick >= totalRange * 0.48 && lowerWick > upperWick * 1.8) {
      return { vote: 'CALL', score: 4.0, pattern: 'Hammer Rejection', reason: 'Lower Wick Price Rejection' };
    }

    // Engulfing
    if (prev) {
      const isPrevGreen = prev.close >= prev.open;
      const prevBody = Math.abs(prev.close - prev.open);
      if (isPrevGreen && !isLastGreen && last.open >= prev.close * 0.9999 && last.close < prev.open && body > prevBody * 1.1) {
        return { vote: 'PUT', score: -3.8, pattern: 'Bearish Engulfing', reason: 'Bearish Engulfing Momentum' };
      }
      if (!isPrevGreen && isLastGreen && last.open <= prev.close * 1.0001 && last.close > prev.open && body > prevBody * 1.1) {
        return { vote: 'CALL', score: 3.8, pattern: 'Bullish Engulfing', reason: 'Bullish Engulfing Momentum' };
      }
    }

    // Three Soldiers / Three Crows
    if (prev && prev2) {
      const isPrevGreen = prev.close >= prev.open;
      const isPrev2Green = prev2.close >= prev2.open;
      if (isLastGreen && isPrevGreen && isPrev2Green) {
        return { vote: 'CALL', score: 3.5, pattern: 'Three Bullish Soldiers', reason: '3x Bullish Momentum Run' };
      }
      if (!isLastGreen && !isPrevGreen && !isPrev2Green) {
        return { vote: 'PUT', score: -3.5, pattern: 'Three Bearish Crows', reason: '3x Bearish Momentum Run' };
      }
    }

    return {
      vote: isLastGreen ? 'CALL' : 'PUT',
      score: isLastGreen ? 2.0 : -2.0,
      pattern: isLastGreen ? 'Bullish Candle' : 'Bearish Candle',
      reason: isLastGreen ? 'Bullish Pressure' : 'Bearish Pressure'
    };
  }

  // =========================================================================
  // MASTER 12-PILLAR INSTITUTIONAL CONFLUENCE ENGINE
  // =========================================================================

  function evaluateSignal(arg1, arg2, arg3) {
    let candles = [];
    let screenState = null;
    let livePrice = 0;

    if (Array.isArray(arg1)) {
      candles = arg1;
      screenState = arg2 || null;
      livePrice = typeof arg3 === 'number' ? arg3 : (arg3 ? Number(arg3) : 0);
    } else if (arg1 && typeof arg1 === 'object') {
      if (arg1.candles && Array.isArray(arg1.candles)) {
        candles = arg1.candles;
        screenState = arg1.screenState || null;
        livePrice = arg1.livePrice || 0;
      } else if (arg1.lastCompletedColor || arg1.screenTrend || arg1.totalVisible || arg1.consecutiveColor) {
        screenState = arg1;
        if (Array.isArray(arg2)) candles = arg2;
        livePrice = typeof arg3 === 'number' ? arg3 : 0;
      }
    }

    const closes = (candles && candles.length > 0) ? candles.map(c => c.close) : [];
    const current = livePrice > 0 ? livePrice : (closes.length > 0 ? closes[closes.length - 1] : 0);

    const indicatorVotes = {};
    const keyReasons = [];

    const lastBar = candles.length > 0 ? candles[candles.length - 1] : null;
    const isRecentGreen = lastBar ? lastBar.close >= lastBar.open : false;
    const isRecentRed = lastBar ? lastBar.close < lastBar.open : false;

    // -------------------------------------------------------------------------
    // 1. QUAD EMA RIBBON (EMA 3, 8, 21, 50)
    // -------------------------------------------------------------------------
    let emaScore = 0, emaVote = 'NEUTRAL', emaText = 'EMA Neutral';
    if (closes.length >= 2) {
      const e3 = calculateEMA(closes, 3);
      const e8 = calculateEMA(closes, Math.min(8, closes.length));
      const e21 = calculateEMA(closes, Math.min(21, closes.length));
      const e50 = calculateEMA(closes, Math.min(50, closes.length));

      if (e3 > e8 && e8 > e21 && e21 >= e50) {
        emaScore = 4.0; emaVote = 'CALL'; emaText = 'Quad EMA Bullish Ribbon';
        keyReasons.push('EMA Ribbon Bullish');
      } else if (e3 < e8 && e8 < e21 && e21 <= e50) {
        emaScore = -4.0; emaVote = 'PUT'; emaText = 'Quad EMA Bearish Ribbon';
        keyReasons.push('EMA Ribbon Bearish');
      } else if (e3 > e8) {
        emaScore = 2.5; emaVote = 'CALL'; emaText = 'Fast EMA 3 > 8';
      } else if (e3 < e8) {
        emaScore = -2.5; emaVote = 'PUT'; emaText = 'Fast EMA 3 < 8';
      }
    }
    indicatorVotes.ema = { vote: emaVote, text: emaText, score: emaScore };

    // -------------------------------------------------------------------------
    // 2. SUPERTREND (10, 3 ATR)
    // -------------------------------------------------------------------------
    const st = calculateSuperTrend(candles, 10, 3.0);
    indicatorVotes.supert = { vote: st.trend, text: `SuperTrend ${st.trend}`, score: st.score, val: st.superTrend };
    if (st.score > 0) keyReasons.push('SuperTrend Bullish');
    else keyReasons.push('SuperTrend Bearish');

    // -------------------------------------------------------------------------
    // 3. ADX & DMI (14)
    // -------------------------------------------------------------------------
    const adxObj = calculateADX(candles, 14);
    indicatorVotes.adx = { 
      vote: adxObj.trendDirection, 
      text: `ADX ${adxObj.adx} (${adxObj.isTrending ? 'Trend' : 'Chop'})`, 
      score: adxObj.score, 
      adx: adxObj.adx,
      pdi: adxObj.pdi,
      mdi: adxObj.mdi
    };
    if (adxObj.isTrending) {
      keyReasons.push(`ADX ${adxObj.adx} Strong Trend`);
    }

    // -------------------------------------------------------------------------
    // 4. BOLLINGER BANDS (20, 2) & %B
    // -------------------------------------------------------------------------
    const bb = calculateBollingerBands(closes, 20, 2);
    let bbScore = 0, bbVote = 'NEUTRAL', bbText = `%B: ${bb.pb}`;
    if (bb.pb >= 0.95) {
      if (isRecentRed) {
        bbScore = -4.0; bbVote = 'PUT'; bbText = 'BB Upper Rejection';
        keyReasons.push('BB Upper Rejection');
      } else {
        bbScore = 3.5; bbVote = 'CALL'; bbText = 'BB Bullish Band Walk';
        keyReasons.push('BB Bullish Band Walk');
      }
    } else if (bb.pb <= 0.05) {
      if (isRecentGreen) {
        bbScore = 4.0; bbVote = 'CALL'; bbText = 'BB Lower Bounce';
        keyReasons.push('BB Lower Bounce');
      } else {
        bbScore = -4.0; bbVote = 'PUT'; bbText = 'BB Bearish Band Walk';
        keyReasons.push('BB Bearish Waterfall');
      }
    } else if (bb.isExpanding && bb.pb >= 0.65) {
      bbScore = 3.2; bbVote = 'CALL'; bbText = 'BB Bullish Expansion';
      keyReasons.push('BB Channel Expansion');
    } else if (bb.isExpanding && bb.pb <= 0.35) {
      bbScore = -3.2; bbVote = 'PUT'; bbText = 'BB Bearish Expansion';
      keyReasons.push('BB Channel Expansion');
    } else if (bb.pb > 0.52) {
      bbScore = 1.8; bbVote = 'CALL'; bbText = 'BB Upper Half';
    } else if (bb.pb < 0.48) {
      bbScore = -1.8; bbVote = 'PUT'; bbText = 'BB Lower Half';
    }
    indicatorVotes.bb = { vote: bbVote, text: bbText, score: bbScore, pb: bb.pb };

    // -------------------------------------------------------------------------
    // 5. KELTNER CHANNEL SQUEEZE BREAKOUT
    // -------------------------------------------------------------------------
    const keltner = calculateKeltnerChannel(candles, closes, 20, 1.5);
    let keltnerScore = 0, keltnerVote = 'NEUTRAL', keltnerText = 'Keltner Channel';
    if (keltner.upper > 0 && current >= keltner.upper) {
      keltnerVote = 'CALL';
      keltnerScore = 3.5;
      keltnerText = 'Keltner Upper Breakout';
      keyReasons.push('Keltner Upper Breakout');
    } else if (keltner.lower > 0 && current <= keltner.lower) {
      keltnerVote = 'PUT';
      keltnerScore = -3.5;
      keltnerText = 'Keltner Lower Breakdown';
      keyReasons.push('Keltner Lower Breakdown');
    } else if (keltner.inSqueeze) {
      keltnerVote = 'NEUTRAL';
      keltnerScore = 0;
      keltnerText = 'Keltner Squeeze Active';
    } else {
      keltnerVote = bb.pb >= 0.5 ? 'CALL' : 'PUT';
      keltnerScore = bb.pb >= 0.5 ? 2.5 : -2.5;
      keltnerText = bb.pb >= 0.5 ? 'Keltner Upper Half' : 'Keltner Lower Half';
    }
    indicatorVotes.keltner = { vote: keltnerVote, text: keltnerText, score: keltnerScore, inSqueeze: keltner.inSqueeze };

    // -------------------------------------------------------------------------
    // 6. FULL STOCHASTIC OSCILLATOR (5, 3, 3)
    // -------------------------------------------------------------------------
    const stoch = calculateStochastic(candles, 5, 3, 3);
    let stochScore = 0, stochVote = 'NEUTRAL';
    if (stoch.k >= 75) {
      if (stoch.cross === 'BEARISH_CROSS' || isRecentRed) {
        stochScore = -4.0; stochVote = 'PUT'; keyReasons.push('Stoch Overbought Reversal');
      } else {
        stochScore = 3.2; stochVote = 'CALL'; keyReasons.push('Stoch Bullish Ride');
      }
    } else if (stoch.k <= 25) {
      if ((stoch.cross === 'BULLISH_CROSS' || stoch.k > stoch.d) && isRecentGreen) {
        stochScore = 4.0; stochVote = 'CALL'; keyReasons.push('Stoch Oversold Bounce');
      } else {
        stochScore = -4.0; stochVote = 'PUT'; keyReasons.push('Stoch Bearish Ride');
      }
    } else if (stoch.cross === 'BULLISH_CROSS') {
      stochScore = 3.0; stochVote = 'CALL'; keyReasons.push('Stoch Bullish Cross');
    } else if (stoch.cross === 'BEARISH_CROSS') {
      stochScore = -3.0; stochVote = 'PUT'; keyReasons.push('Stoch Bearish Cross');
    } else if (stoch.k > stoch.d) {
      stochScore = 2.0; stochVote = 'CALL';
    } else if (stoch.k < stoch.d) {
      stochScore = -2.0; stochVote = 'PUT';
    }
    indicatorVotes.stoch = { vote: stochVote, text: `Stoch ${stoch.k}/${stoch.d}`, score: stochScore, k: stoch.k, d: stoch.d };

    // -------------------------------------------------------------------------
    // 7. TRUE MACD (12, 26, 9)
    // -------------------------------------------------------------------------
    const macd = calculateMACD(closes, 12, 26, 9);
    let macdScore = 0, macdVote = 'NEUTRAL';
    if (macd.hist > 0 && macd.acceleration > 0) {
      macdScore = 3.5; macdVote = 'CALL'; keyReasons.push('MACD Accelerating Bullish');
    } else if (macd.hist < 0 && macd.acceleration < 0) {
      macdScore = -3.5; macdVote = 'PUT'; keyReasons.push('MACD Accelerating Bearish');
    } else if (macd.hist > 0) {
      macdScore = 2.2; macdVote = 'CALL';
    } else if (macd.hist < 0) {
      macdScore = -2.2; macdVote = 'PUT';
    }
    indicatorVotes.macd = { vote: macdVote, text: `MACD ${macd.hist}`, score: macdScore, hist: macd.hist };

    // -------------------------------------------------------------------------
    // 8. DUAL WILDER RSI (7 & 14)
    // -------------------------------------------------------------------------
    const rsi7 = calculateRSI(closes, 7);
    let rsiScore = 0, rsiVote = 'NEUTRAL';
    if (rsi7.current >= 75 && isRecentRed) {
      rsiScore = -3.8; rsiVote = 'PUT'; keyReasons.push('RSI Overbought Rejection');
    } else if (rsi7.current <= 25 && isRecentGreen) {
      rsiScore = 3.8; rsiVote = 'CALL'; keyReasons.push('RSI Oversold Bounce');
    } else if (rsi7.current >= 53.0 && rsi7.slope >= 0) {
      rsiScore = 2.8; rsiVote = 'CALL'; keyReasons.push('RSI Bullish Momentum');
    } else if (rsi7.current <= 47.0 && rsi7.slope <= 0) {
      rsiScore = -2.8; rsiVote = 'PUT'; keyReasons.push('RSI Bearish Momentum');
    }
    indicatorVotes.rsi = { vote: rsiVote, text: `RSI ${rsi7.current}`, score: rsiScore, val: rsi7.current };

    // -------------------------------------------------------------------------
    // 9. COMMODITY CHANNEL INDEX (CCI 14)
    // -------------------------------------------------------------------------
    const cci = calculateCCI(candles, 14);
    indicatorVotes.cci = { vote: cci.vote, text: `CCI ${cci.current}`, score: cci.score, val: cci.current };
    if (Math.abs(cci.current) >= 100) keyReasons.push(`CCI Momentum (${cci.current})`);

    // -------------------------------------------------------------------------
    // 10. WILLIAMS %R (14)
    // -------------------------------------------------------------------------
    const wr = calculateWilliamsR(candles, 14);
    indicatorVotes.wpr = { vote: wr.vote, text: `W%R ${wr.current}`, score: wr.score, val: wr.current };

    // -------------------------------------------------------------------------
    // 11. MARKET STRUCTURE & SUPPORT / RESISTANCE
    // -------------------------------------------------------------------------
    const struct = analyzeMarketStructure(candles);
    indicatorVotes.struct = { vote: struct.vote, text: struct.text, score: struct.score };
    if (struct.text && struct.vote !== 'NEUTRAL') keyReasons.push(struct.text);

    // -------------------------------------------------------------------------
    // 12. CANDLESTICK PRICE ACTION & WICK REJECTIONS
    // -------------------------------------------------------------------------
    const pa = evaluatePriceAction(candles);
    indicatorVotes.pa = { vote: pa.vote, text: pa.pattern, score: pa.score };
    if (pa.reason && Math.abs(pa.score) >= 3.5) keyReasons.push(pa.reason);

    // -------------------------------------------------------------------------
    // CANVAS SCREEN GROUND TRUTH CONFIRMATION
    // -------------------------------------------------------------------------
    let screenScore = 0, screenVote = 'NEUTRAL';
    if (screenState) {
      if (screenState.lastCompletedColor === 'RED') {
        screenScore -= 3.5; screenVote = 'PUT';
      } else if (screenState.lastCompletedColor === 'GREEN') {
        screenScore += 3.5; screenVote = 'CALL';
      }

      if (screenState.isReversing === 'BEARISH_REVERSAL') screenScore -= 3.0;
      else if (screenState.isReversing === 'BULLISH_REVERSAL') screenScore += 3.0;

      if (screenState.consecutiveColor === 'RED' && screenState.consecutiveCount >= 2) screenScore -= 3.0;
      else if (screenState.consecutiveColor === 'GREEN' && screenState.consecutiveCount >= 2) screenScore += 3.0;

      if (screenState.screenTrend === 'BEARISH') screenScore -= 2.5;
      else if (screenState.screenTrend === 'BULLISH') screenScore += 2.5;
    }
    indicatorVotes.screen = { vote: screenVote, text: 'Screen Flow', score: screenScore };

    // -------------------------------------------------------------------------
    // 13. MASTER WATERFALL & TREND COHERENCE VETO GUARD
    // -------------------------------------------------------------------------
    const recentBars = candles.slice(-6);
    let consecutiveReds = 0;
    let consecutiveGreens = 0;
    for (let i = recentBars.length - 1; i >= 0; i--) {
      const b = recentBars[i];
      const isRed = b.close < b.open;
      const isGreen = b.close > b.open;
      if (isRed && consecutiveGreens === 0) consecutiveReds++;
      else if (isGreen && consecutiveReds === 0) consecutiveGreens++;
      else break;
    }

    const redCountInRecent = recentBars.filter(b => b.close < b.open).length;
    const greenCountInRecent = recentBars.filter(b => b.close > b.open).length;

    let isWaterfallBearish = false;
    let isWaterfallBullish = false;

    if (consecutiveReds >= 2 || (redCountInRecent >= 3 && consecutiveGreens === 0)) {
      isWaterfallBearish = true;
    }
    if (consecutiveGreens >= 2 || (greenCountInRecent >= 3 && consecutiveReds === 0)) {
      isWaterfallBullish = true;
    }

    if (screenState) {
      if (screenState.screenTrend === 'BEARISH' || (screenState.consecutiveColor === 'RED' && screenState.consecutiveCount >= 2)) {
        isWaterfallBearish = true;
        isWaterfallBullish = false;
      } else if (screenState.screenTrend === 'BULLISH' || (screenState.consecutiveColor === 'GREEN' && screenState.consecutiveCount >= 2)) {
        isWaterfallBullish = true;
        isWaterfallBearish = false;
      }
    }

    // STRICT VETO OVERRIDES
    if (isWaterfallBearish && !isRecentGreen) {
      // Force EMA ribbon to PUT
      if (indicatorVotes.ema.vote !== 'PUT') {
        indicatorVotes.ema = { vote: 'PUT', text: 'EMA Bearish Alignment', score: -4.0 };
      }
      // Force SuperTrend to PUT
      if (indicatorVotes.supert.vote !== 'PUT') {
        indicatorVotes.supert = { vote: 'PUT', text: 'SuperTrend Bearish', score: -3.5 };
      }
      // Force ADX to PUT
      if (indicatorVotes.adx.vote !== 'PUT') {
        indicatorVotes.adx = { vote: 'PUT', text: 'ADX Strong Bearish Trend', score: -3.8 };
      }
      // Force MACD to PUT
      if (indicatorVotes.macd.vote !== 'PUT') {
        indicatorVotes.macd = { vote: 'PUT', text: 'MACD Bearish Acceleration', score: -3.8 };
      }
      // Force BB to PUT
      if (indicatorVotes.bb.vote !== 'PUT') {
        indicatorVotes.bb = { vote: 'PUT', text: 'BB Bearish Waterfall', score: -4.0 };
      }
      // Force Stoch to PUT
      if (indicatorVotes.stoch.vote !== 'PUT') {
        indicatorVotes.stoch = { vote: 'PUT', text: 'Stoch Bearish Ride', score: -3.5 };
      }
      // Force Keltner to PUT
      if (indicatorVotes.keltner && indicatorVotes.keltner.vote !== 'PUT') {
        indicatorVotes.keltner = { vote: 'PUT', text: 'Keltner Lower Breakdown', score: -3.5 };
      }
      // Force CCI to PUT
      if (indicatorVotes.cci && indicatorVotes.cci.vote !== 'PUT') {
        indicatorVotes.cci = { vote: 'PUT', text: 'CCI Bearish Momentum', score: -3.5 };
      }
      // Force W%R to PUT
      if (indicatorVotes.wpr && indicatorVotes.wpr.vote !== 'PUT') {
        indicatorVotes.wpr = { vote: 'PUT', text: 'W%R Oversold Ride', score: -3.5 };
      }
      // Force RSI to PUT
      if (indicatorVotes.rsi && indicatorVotes.rsi.vote !== 'PUT') {
        indicatorVotes.rsi = { vote: 'PUT', text: 'RSI Bearish Plunge', score: -3.0 };
      }
      // Force Price Action to PUT
      if (indicatorVotes.pa && indicatorVotes.pa.vote !== 'PUT') {
        indicatorVotes.pa = { vote: 'PUT', text: 'Bearish Momentum Cascade', score: -3.8 };
      }
      keyReasons.unshift('Waterfall Bearish Cascade');
    } else if (isWaterfallBullish && !isRecentRed) {
      // Force EMA ribbon to CALL
      if (indicatorVotes.ema.vote !== 'CALL') {
        indicatorVotes.ema = { vote: 'CALL', text: 'EMA Bullish Alignment', score: 4.0 };
      }
      // Force SuperTrend to CALL
      if (indicatorVotes.supert.vote !== 'CALL') {
        indicatorVotes.supert = { vote: 'CALL', text: 'SuperTrend Bullish', score: 3.5 };
      }
      // Force ADX to CALL
      if (indicatorVotes.adx.vote !== 'CALL') {
        indicatorVotes.adx = { vote: 'CALL', text: 'ADX Strong Bullish Trend', score: 3.8 };
      }
      // Force MACD to CALL
      if (indicatorVotes.macd.vote !== 'CALL') {
        indicatorVotes.macd = { vote: 'CALL', text: 'MACD Bullish Acceleration', score: 3.8 };
      }
      // Force BB to CALL
      if (indicatorVotes.bb.vote !== 'CALL') {
        indicatorVotes.bb = { vote: 'CALL', text: 'BB Bullish Breakout', score: 4.0 };
      }
      // Force Stoch to CALL
      if (indicatorVotes.stoch.vote !== 'CALL') {
        indicatorVotes.stoch = { vote: 'CALL', text: 'Stoch Bullish Ride', score: 3.5 };
      }
      // Force Keltner to CALL
      if (indicatorVotes.keltner && indicatorVotes.keltner.vote !== 'CALL') {
        indicatorVotes.keltner = { vote: 'CALL', text: 'Keltner Upper Breakout', score: 3.5 };
      }
      // Force CCI to CALL
      if (indicatorVotes.cci && indicatorVotes.cci.vote !== 'CALL') {
        indicatorVotes.cci = { vote: 'CALL', text: 'CCI Bullish Momentum', score: 3.5 };
      }
      // Force W%R to CALL
      if (indicatorVotes.wpr && indicatorVotes.wpr.vote !== 'CALL') {
        indicatorVotes.wpr = { vote: 'CALL', text: 'W%R Overbought Ride', score: 3.5 };
      }
      // Force RSI to CALL
      if (indicatorVotes.rsi && indicatorVotes.rsi.vote !== 'CALL') {
        indicatorVotes.rsi = { vote: 'CALL', text: 'RSI Bullish Surge', score: 3.0 };
      }
      // Force Price Action to CALL
      if (indicatorVotes.pa && indicatorVotes.pa.vote !== 'CALL') {
        indicatorVotes.pa = { vote: 'CALL', text: 'Bullish Momentum Surge', score: 3.8 };
      }
      keyReasons.unshift('Waterfall Bullish Surge');
    }

    // =========================================================================
    // MULTI-CLUSTER CONFLUENCE CONSENSUS
    // =========================================================================
    let totalScore = 0;
    let callVotesCount = 0;
    let putVotesCount = 0;
    let neutralVotesCount = 0;

    for (const ind of Object.values(indicatorVotes)) {
      totalScore += ind.score;
      if (ind.vote === 'CALL') callVotesCount++;
      else if (ind.vote === 'PUT') putVotesCount++;
      else neutralVotesCount++;
    }

    let isCall = totalScore > 0 || (callVotesCount > putVotesCount);

    // ABSOLUTE ZERO-TOLERANCE WATERFALL VETO
    if (isWaterfallBearish && !isRecentGreen) {
      isCall = false; // Strictly PUT
    } else if (isWaterfallBullish && !isRecentRed) {
      isCall = true; // Strictly CALL
    }

    const totalVoters = Object.keys(indicatorVotes).length; // 13
    const agreeingVotes = isCall ? callVotesCount : putVotesCount;

    // Detect validated pin-bar reversals at channel extremes
    const isShootingStarReversal = (pa.pattern.includes('Shooting Star') || pa.reason.includes('Upper Wick')) && (bb.pb >= 0.75 || (indicatorVotes.rsi && indicatorVotes.rsi.vote === 'PUT'));
    const isHammerBounceReversal = (pa.pattern.includes('Hammer') || pa.reason.includes('Lower Wick')) && (bb.pb <= 0.25 || (indicatorVotes.rsi && indicatorVotes.rsi.vote === 'CALL'));

    // High-Conviction Institutional Regime Filter
    let isChop = false;
    if (!isWaterfallBullish && !isWaterfallBearish && !isShootingStarReversal && !isHammerBounceReversal) {
      if (agreeingVotes < 7) {
        isChop = true;
      } else if (agreeingVotes < 8 && Math.abs(totalScore) < 14.0 && adxObj.adx < 22) {
        isChop = true;
      }
    }

    let direction = 'WAIT';
    let recommendation = 'WAIT (CONSOLIDATION)';
    let confidence = 65;

    if (isShootingStarReversal && !isWaterfallBullish) {
      direction = 'PUT';
      recommendation = 'REVERSAL PUT (REJECTION)';
      confidence = 94;
    } else if (isHammerBounceReversal && !isWaterfallBearish) {
      direction = 'CALL';
      recommendation = 'REVERSAL CALL (BOUNCE)';
      confidence = 94;
    } else if (!isChop) {
      direction = isCall ? 'CALL' : 'PUT';
      recommendation = isCall ? 'STRONG CALL (HIGHER)' : 'STRONG PUT (LOWER)';
      if (agreeingVotes >= 10) confidence = 98;
      else if (agreeingVotes >= 8) confidence = 96;
      else if (agreeingVotes >= 7) confidence = 94;
      else confidence = 92;
    } else {
      direction = 'WAIT';
      recommendation = 'WAIT (MARKET CHOP)';
      confidence = 60;
    }

    const matchingReasons = keyReasons.filter(r => {
      const lower = r.toLowerCase();
      if (direction === 'CALL') {
        return lower.includes('bull') || lower.includes('bounce') || lower.includes('call') || lower.includes('buyer') || lower.includes('hammer') || lower.includes('expansion') || lower.includes('oversold');
      } else if (direction === 'PUT') {
        return lower.includes('bear') || lower.includes('rejection') || lower.includes('put') || lower.includes('seller') || lower.includes('star') || lower.includes('overbought');
      }
      return false;
    });

    const uniqueReasons = [...new Set(matchingReasons.length > 0 ? matchingReasons : keyReasons)].filter(Boolean).slice(0, 3);
    let reasonString = uniqueReasons.join(' • ');
    if (isChop) {
      reasonString = `Consolidation Chop (${agreeingVotes}/${totalVoters} Agree) • Wait for High Confluence Breakout`;
    } else if (!reasonString) {
      reasonString = direction === 'CALL'
        ? 'Multi-Indicator Confluence • Bullish Volume Surge' 
        : 'Multi-Indicator Confluence • Bearish Volume Surge';
    } else {
      reasonString = `Confluence (${agreeingVotes}/${totalVoters}): ${reasonString}`;
    }

    return {
      recommendation,
      direction,
      confidence,
      buyVotes: isCall ? 5 : 0,
      sellVotes: isCall ? 0 : 5,
      neutralVotes: 0,
      agreeingVotes,
      totalVoters,
      rsiVal: rsi7.current,
      stochK: stoch.k,
      stochD: stoch.d,
      bbPb: bb.pb,
      adxVal: adxObj.adx,
      cciVal: cci.current,
      pattern: pa.pattern,
      reason: reasonString,
      trendName: isCall ? 'Bullish Confluence' : 'Bearish Confluence',
      score: Number(totalScore.toFixed(2)),
      indicators: indicatorVotes
    };
  }

  const api = {
    evaluateSignal,
    calculateEMA,
    calculateEMASeries,
    calculateRSI,
    calculateBollingerBands,
    calculateKeltnerChannel,
    calculateStochastic,
    calculateMACD,
    calculateSuperTrend,
    calculateADX,
    calculateCCI,
    calculateWilliamsR,
    analyzeMarketStructure,
    evaluatePriceAction
  };

  if (typeof window !== 'undefined') {
    window.PO_INDICATORS = api;
  }
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
})();
