/**
 * Test Suite for Pocket Signal Pro Institutional Quantitative Engine (v1.9.0)
 */
const indicators = require('./indicators.js');
const assert = require('assert');

console.log('🧪 Starting Quantitative Indicator Engine Verification Suite...\n');

// Helper to generate simulated candles
function generateTrendCandles(startPrice, count, direction = 'UP') {
  const candles = [];
  let p = startPrice;
  const step = startPrice * 0.0002;
  for (let i = 0; i < count; i++) {
    const isUp = direction === 'UP';
    const open = p;
    const close = isUp ? open + step : open - step;
    const high = Math.max(open, close) + step * 0.3;
    const low = Math.min(open, close) - step * 0.3;
    candles.push({ open, high, low, close });
    p = close;
  }
  return candles;
}

// --------------------------------------------------------------------------
// TEST 1: Strong Bullish Trend
// --------------------------------------------------------------------------
console.log('--- Test 1: Strong Bullish Trend ---');
const bullCandles = generateTrendCandles(1.84000, 35, 'UP');
const bullSignal = indicators.evaluateSignal(bullCandles, { lastCompletedColor: 'GREEN', screenTrend: 'BULLISH' }, 1.84700);

console.log('Direction:', bullSignal.direction);
console.log('Recommendation:', bullSignal.recommendation);
console.log('Confidence:', bullSignal.confidence + '%');
console.log('Score:', bullSignal.score);
console.log('Agreeing Votes:', `${bullSignal.agreeingVotes}/${bullSignal.totalVoters}`);
console.log('RSI(7):', bullSignal.rsiVal);
console.log('Stoch %K/%D:', `${bullSignal.stochK}/${bullSignal.stochD}`);
console.log('Reason:', bullSignal.reason);

assert.strictEqual(bullSignal.direction, 'CALL', 'Bullish trend must produce CALL signal');
assert(bullSignal.confidence >= 92, 'Bullish trend confidence must be >= 92%');
assert(bullSignal.agreeingVotes >= 5, 'At least 5 indicators must agree on CALL');
console.log('✅ Test 1 Passed!\n');

// --------------------------------------------------------------------------
// TEST 2: Strong Bearish Trend
// --------------------------------------------------------------------------
console.log('--- Test 2: Strong Bearish Trend ---');
const bearCandles = generateTrendCandles(1.84000, 35, 'DOWN');
const bearSignal = indicators.evaluateSignal(bearCandles, { lastCompletedColor: 'RED', screenTrend: 'BEARISH' }, 1.83300);

console.log('Direction:', bearSignal.direction);
console.log('Recommendation:', bearSignal.recommendation);
console.log('Confidence:', bearSignal.confidence + '%');
console.log('Score:', bearSignal.score);
console.log('Agreeing Votes:', `${bearSignal.agreeingVotes}/${bearSignal.totalVoters}`);
console.log('RSI(7):', bearSignal.rsiVal);
console.log('Stoch %K/%D:', `${bearSignal.stochK}/${bearSignal.stochD}`);
console.log('Reason:', bearSignal.reason);

assert.strictEqual(bearSignal.direction, 'PUT', 'Bearish trend must produce PUT signal');
assert(bearSignal.confidence >= 92, 'Bearish trend confidence must be >= 92%');
assert(bearSignal.agreeingVotes >= 5, 'At least 5 indicators must agree on PUT');
console.log('✅ Test 2 Passed!\n');

// --------------------------------------------------------------------------
// TEST 3: Upper Bollinger Band Rejection (Shooting Star Pin-Bar)
// --------------------------------------------------------------------------
console.log('--- Test 3: Upper BB Rejection (Shooting Star Pin-Bar) ---');
const reversalUpCandles = generateTrendCandles(1.84000, 30, 'UP');
// Append a shooting star pin-bar at the upper band
const topPrice = reversalUpCandles[reversalUpCandles.length - 1].close;
reversalUpCandles.push({
  open: topPrice,
  high: topPrice + 0.00060, // Long upper wick
  low: topPrice - 0.00005,
  close: topPrice - 0.00010 // Red body
});

const topSignal = indicators.evaluateSignal(reversalUpCandles, { lastCompletedColor: 'RED', isReversing: 'BEARISH_REVERSAL' });
console.log('Pattern detected:', topSignal.pattern);
console.log('Direction:', topSignal.direction);
console.log('BB %B:', topSignal.bbPb);
console.log('Indicators:', Object.entries(topSignal.indicators).map(([k, v]) => `${k}:${v.vote}`).join(' | '));
console.log('Reason:', topSignal.reason);

assert.strictEqual(topSignal.direction, 'PUT', 'Upper band rejection must trigger PUT');
assert(topSignal.pattern.includes('Shooting Star') || topSignal.pattern.includes('Bearish'), 'Pattern should reflect bearish rejection');
console.log('✅ Test 3 Passed!\n');

// --------------------------------------------------------------------------
// TEST 4: Lower Bollinger Band Bounce (Hammer Pin-Bar)
// --------------------------------------------------------------------------
console.log('--- Test 4: Lower BB Bounce (Hammer Pin-Bar) ---');
const reversalDownCandles = generateTrendCandles(1.84000, 30, 'DOWN');
// Append a hammer pin-bar at the lower band
const bottomPrice = reversalDownCandles[reversalDownCandles.length - 1].close;
reversalDownCandles.push({
  open: bottomPrice,
  high: bottomPrice + 0.00005,
  low: bottomPrice - 0.00060, // Long lower wick
  close: bottomPrice + 0.00010 // Green body
});

const bottomSignal = indicators.evaluateSignal(reversalDownCandles, { lastCompletedColor: 'GREEN', isReversing: 'BULLISH_REVERSAL' });
console.log('Pattern detected:', bottomSignal.pattern);
console.log('Direction:', bottomSignal.direction);
console.log('BB %B:', bottomSignal.bbPb);
console.log('Indicators:', Object.entries(bottomSignal.indicators).map(([k, v]) => `${k}:${v.vote}`).join(' | '));
console.log('Reason:', bottomSignal.reason);

assert.strictEqual(bottomSignal.direction, 'CALL', 'Lower band bounce must trigger CALL');
assert(bottomSignal.pattern.includes('Hammer') || bottomSignal.pattern.includes('Bullish'), 'Pattern should reflect bullish rejection');
console.log('✅ Test 4 Passed!\n');

// --------------------------------------------------------------------------
// TEST 5: Sideways Consolidation & Neutral Deadzone
// --------------------------------------------------------------------------
console.log('--- Test 5: Sideways Consolidation & Deadzone ---');
const chopCandles = [];
let chopPrice = 1.84000;
for (let i = 0; i < 35; i++) {
  const isUp = (i % 2 === 0);
  const open = chopPrice;
  const close = isUp ? open + 0.00003 : open - 0.00003;
  chopCandles.push({ open, high: open + 0.00005, low: open - 0.00005, close });
  chopPrice = close;
}
const chopSignal = indicators.evaluateSignal(chopCandles, null, chopPrice);
console.log('Direction:', chopSignal.direction);
console.log('RSI(7):', chopSignal.rsiVal);
console.log('Indicators:', Object.entries(chopSignal.indicators).map(([k, v]) => `${k}:${v.vote}`).join(' | '));
console.log('Reason:', chopSignal.reason);
// --------------------------------------------------------------------------
// TEST 6: Real Canvas Candlestick Geometry & Visual Trend
// --------------------------------------------------------------------------
console.log('--- Test 6: Real Canvas Candlestick Geometry ---');
const canvasScreenCandles = [];
for (let i = 0; i < 25; i++) {
  const isGreen = i >= 18; // 18 red bars followed by 7 green reversal bars
  const baseCanvasY = isGreen ? (300 - ((i - 18) * 12)) : (100 + (i * 10));
  canvasScreenCandles.push({
    x: 50 + (i * 18),
    color: isGreen ? 'GREEN' : 'RED',
    topY: isGreen ? baseCanvasY - 10 : baseCanvasY,
    bottomY: isGreen ? baseCanvasY : baseCanvasY + 10,
    highY: isGreen ? baseCanvasY - 14 : baseCanvasY - 4,
    lowY: isGreen ? baseCanvasY + 4 : baseCanvasY + 14
  });
}

const canvasState = {
  lastCompletedColor: 'GREEN',
  screenTrend: 'BULLISH',
  realScreenCandles: canvasScreenCandles,
  recentColors: canvasScreenCandles.slice(-8).map(c => c.color)
};

// Reconstruct candles exactly like content.js does
const profileBase = 1.84090;
const minHighY = Math.min(...canvasScreenCandles.map(c => c.highY));
const maxLowY = Math.max(...canvasScreenCandles.map(c => c.lowY));
const pixelSpan = Math.max(30, maxLowY - minHighY);
const priceSpan = profileBase * 0.0016;
const scale = priceSpan / pixelSpan;
const activeBar = canvasScreenCandles[canvasScreenCandles.length - 1];
const anchorY = activeBar.color === 'GREEN' ? activeBar.topY : activeBar.bottomY;
const priceFromY = (y) => profileBase + ((anchorY - y) * scale);

const reconstructedBars = canvasScreenCandles.map(c => {
  const isGreen = c.color === 'GREEN';
  const open = isGreen ? priceFromY(c.bottomY) : priceFromY(c.topY);
  const close = isGreen ? priceFromY(c.topY) : priceFromY(c.bottomY);
  const high = Math.max(open, close, priceFromY(c.highY));
  const low = Math.min(open, close, priceFromY(c.lowY));
  return { open, high, low, close };
});

const canvasSignal = indicators.evaluateSignal(reconstructedBars, canvasState, profileBase);
console.log('Direction:', canvasSignal.direction);
console.log('Recommendation:', canvasSignal.recommendation);
console.log('Confidence:', canvasSignal.confidence + '%');
console.log('Reason:', canvasSignal.reason);
console.log('Indicators:', Object.entries(canvasSignal.indicators).map(([k, v]) => `${k}:${v.vote}`).join(' | '));

assert.strictEqual(canvasSignal.direction, 'CALL', 'Reversal green run must trigger CALL');
console.log('✅ Test 6 Passed!\n');

// --------------------------------------------------------------------------
// TEST 7: AUD/CAD OTC 6-Candle Red Waterfall Crash (Exact User Screenshot)
// --------------------------------------------------------------------------
console.log('--- Test 7: AUD/CAD OTC 6-Candle Red Waterfall Crash ---');
const waterfallCandles = [];
let crashPrice = 0.99490;
for (let i = 0; i < 6; i++) {
  const step = 0.00094;
  waterfallCandles.push({
    open: crashPrice,
    high: crashPrice + 0.00008,
    low: crashPrice - step - 0.00008,
    close: crashPrice - step
  });
  crashPrice -= step;
}
const screenshotSignal = indicators.evaluateSignal(waterfallCandles, {
  lastCompletedColor: 'RED',
  consecutiveColor: 'RED',
  consecutiveCount: 5,
  screenTrend: 'BEARISH'
}, 0.98924);

console.log('Direction:', screenshotSignal.direction);
console.log('Recommendation:', screenshotSignal.recommendation);
console.log('Confidence:', screenshotSignal.confidence + '%');
console.log('Score:', screenshotSignal.score);
console.log('Agreeing Votes:', `${screenshotSignal.agreeingVotes}/${screenshotSignal.totalVoters}`);
console.log('Reason:', screenshotSignal.reason);
console.log('Indicators:', Object.entries(screenshotSignal.indicators).map(([k, v]) => `${k}:${v.vote}`).join(' | '));

assert.strictEqual(screenshotSignal.direction, 'PUT', 'AUD/CAD OTC Waterfall MUST produce PUT signal');
assert.strictEqual(screenshotSignal.recommendation, 'STRONG PUT (LOWER)', 'Recommendation must be STRONG PUT (LOWER)');
assert(screenshotSignal.agreeingVotes >= 9, 'At least 9 indicators must agree on PUT');
assert(screenshotSignal.confidence >= 96, 'Confidence must be >= 96%');
console.log('✅ Test 7 Passed!\n');

// --------------------------------------------------------------------------
// TEST 8: AUD/USD OTC 3-Candle Green Breakout Rally (User Screenshot 2)
// --------------------------------------------------------------------------
console.log('--- Test 8: AUD/USD OTC 3-Candle Green Breakout Rally ---');
const rallyCandles = [
  { open: 0.70200, high: 0.70298, low: 0.70195, close: 0.70295 },
  { open: 0.70295, high: 0.70315, low: 0.70280, close: 0.70310 },
  { open: 0.70310, high: 0.70342, low: 0.70305, close: 0.70337 },
  { open: 0.70330, high: 0.70345, low: 0.70325, close: 0.70337 }
];
const breakoutSignal = indicators.evaluateSignal(rallyCandles, {
  lastCompletedColor: 'GREEN',
  consecutiveColor: 'GREEN',
  consecutiveCount: 3,
  screenTrend: 'BULLISH'
}, 0.70337);

console.log('Direction:', breakoutSignal.direction);
console.log('Recommendation:', breakoutSignal.recommendation);
console.log('Confidence:', breakoutSignal.confidence + '%');
console.log('Score:', breakoutSignal.score);
console.log('Agreeing Votes:', `${breakoutSignal.agreeingVotes}/${breakoutSignal.totalVoters}`);
console.log('Reason:', breakoutSignal.reason);
console.log('Indicators:', Object.entries(breakoutSignal.indicators).map(([k, v]) => `${k}:${v.vote}`).join(' | '));

assert.strictEqual(breakoutSignal.direction, 'CALL', 'AUD/USD OTC Bullish Rally MUST produce CALL signal');
assert.strictEqual(breakoutSignal.recommendation, 'STRONG CALL (HIGHER)', 'Recommendation must be STRONG CALL (HIGHER)');
assert(breakoutSignal.agreeingVotes >= 8, 'At least 8 indicators must agree on CALL');
assert(breakoutSignal.confidence >= 96, 'Confidence must be >= 96%');
console.log('✅ Test 8 Passed!\n');

console.log('🎉 ALL QUANTITATIVE TESTS PASSED WITH 100% SUCCESS!');



