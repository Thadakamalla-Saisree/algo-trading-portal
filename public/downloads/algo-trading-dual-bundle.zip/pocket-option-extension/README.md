# Pocket Signal Pro — Commercial 1-Min Trading HUD ($10 USDT Paywall)

A high-accuracy, 1-minute multi-factor binary options signal HUD for **Pocket Option** protected by a **$10 USDT one-time crypto payment system** with direct Binance deposit addresses and an Owner Admin Panel.

---

## 💎 Owner Payment & Admin Details

- **USDT BSC (BEP-20) Binance Address:** `0x86c304c8015c1a51a520e66295ad75f85aa08b60`
- **USDT TRC-20 (Tron) Binance Address:** `TLXS78k5X6cB9zQHzDQeh4NtTddmj7Z8L7`
- **Price:** `10 USDT` (Lifetime Access)
- **Live Cloud Customer Website:** `https://pocket-signal-pro.onrender.com`
- **Live Cloud Admin Dashboard:** `https://pocket-signal-pro.onrender.com/admin`
- **Local Admin URL (if running locally):** `http://localhost:3000/admin`
- **Owner Admin Password:** `Saisree1722$`

---

## ⚡ Cloud Hosting on Render (24/7 Online)

The backend is permanently deployed on Render:
- **Public URL:** `https://pocket-signal-pro.onrender.com`
- **Owner Admin URL:** `https://pocket-signal-pro.onrender.com/admin`
- Runs 24/7/365 even when your laptop is turned off!

---

## 🛡️ How the Owner Admin Dashboard Works

1. Visit **`http://localhost:3000/admin`** in your browser.
2. Enter your password: **`Saisree1722$`**.
3. View:
   - **Total Revenue ($USDT)** calculated live.
   - **Active vs Pending Users** table.
   - **Direct Blockchain Explorer Links** to verify user TxIDs on BscScan / Tronscan.
   - **1-Click Manual Activate Button:** Instantly grant lifetime access to any customer email.
   - **1-Click Revoke Button:** Instantly cancel access if necessary.

---

## 👥 How the Customer / Buyer Experience Works

1. The customer visits **Pocket Option** (`pocketoption.com`, `po.market`, `po-trade.com`, etc.).
2. The sleek glassmorphic **Pocket Signal Pro Access Activation** modal appears.
3. The customer:
   - Registers their email & password.
   - Selects **USDT (TRC-20)** or **USDT (BEP-20)**.
   - Clicks **Copy Address** or scans the on-screen QR Code.
   - Transfers **10 USDT** from their Binance account or crypto wallet.
   - Pastes their **Transaction Hash (TxID)** and clicks **⚡ Verify On-Chain & Unlock Pro HUD**.
4. The system validates the on-chain transfer directly on the Tron or BSC blockchain:
   - Checks recipient address matches your Binance deposit address.
   - Checks amount is 10 USDT.
   - Ensures the TxID has never been used before (anti-reuse protection).
5. Upon confirmation, a cryptographically signed lifetime license is saved in their Chrome storage.
6. The paywall closes and the **full Pocket Signal Pro HUD unlocks immediately with all 7 indicators, live strike, 1-minute expiration timer, and confluence engine!**

---

## 🚀 How to Load / Reload the Extension in Chrome

1. Open **Google Chrome**.
2. Navigate to `chrome://extensions/`.
3. Enable **Developer mode** (toggle in top-right).
4. Click **Load unpacked** and select:
   ```
   C:\Users\Saisree\.gemini\antigravity-ide\scratch\pocket-option-extension
   ```
   *(If already loaded, click the **Refresh 🔄** icon on the extension card).*
5. Open Pocket Option and enjoy!

