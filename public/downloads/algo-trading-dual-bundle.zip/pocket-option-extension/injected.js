/**
 * Pocket Signal Pro — Main World Real-Time Canvas & WebSocket Interceptor (v1.7.2)
 * Injected into the page's MAIN context (world: MAIN) at document_start.
 * Intercepts exact prices drawn on Canvas, visible candlestick colors, and WebSocket streams.
 */
(function() {
  if (window.__PO_SIGNAL_HOOKED__) return;
  window.__PO_SIGNAL_HOOKED__ = true;

  console.log('%c[Pocket Signal Pro] Canvas & Socket Engine Hooked (v2.0.0)', 'color:#00E5FF;font-weight:bold;');

  // Hook WebGL contexts so drawing buffer is preserved for pixel reading
  try {
    const origGetContext = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function(type, attributes) {
      if (type === 'webgl' || type === 'webgl2') {
        attributes = Object.assign({}, attributes || {}, { preserveDrawingBuffer: true });
      }
      return origGetContext.call(this, type, attributes);
    };
  } catch (err) {}

  let lastPriceSent = 0;
  let lastPostTime = 0;
  const candleMap = new Map();
  let lastStatePostTime = 0;

  // Listen for reset events when switching assets
  window.addEventListener('message', (event) => {
    if (event.data && event.data.source === 'PO_CONTENT_SCRIPT' && event.data.type === 'RESET_CANVAS_STATE') {
      candleMap.clear();
      lastStatePostTime = 0;
    }
  });

  // Forgiving color classifier to capture all themes on Pocket Option
  function classifyCandleColor(style) {
    if (!style) return null;
    const s = String(style).trim().toLowerCase();

    // Hex format #RRGGBB
    if (s.startsWith('#') && s.length >= 7) {
      const r = parseInt(s.substring(1, 3), 16);
      const g = parseInt(s.substring(3, 5), 16);
      const b = parseInt(s.substring(5, 7), 16);
      if (g > r + 15 && g >= b - 15) return 'GREEN';
      if (r > g + 15 && r >= b - 15) return 'RED';
    }

    // RGB / RGBA format
    const rgbMatch = s.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    if (rgbMatch) {
      const r = parseInt(rgbMatch[1], 10);
      const g = parseInt(rgbMatch[2], 10);
      const b = parseInt(rgbMatch[3], 10);
      if (g > r + 15 && g >= b - 15) return 'GREEN';
      if (r > g + 15 && r >= b - 15) return 'RED';
    }

    // Known Pocket Option & TradingView greens and reds
    if (s.includes('166, 154') || s.includes('230, 118') || s.includes('green') || 
        s.includes('00e676') || s.includes('26a69a') || s.includes('4caf50') || 
        s.includes('089981') || s.includes('00b07c') || s.includes('rgb(0,') || s.includes('rgb(34, 171')) {
      return 'GREEN';
    }
    if (s.includes('239, 83') || s.includes('255, 23') || s.includes('red') || 
        s.includes('ff1744') || s.includes('ef5350') || s.includes('f44336') || 
        s.includes('f23645') || s.includes('ff4b5c') || s.includes('rgb(255,') || s.includes('rgb(242, 54')) {
      return 'RED';
    }

    return null;
  }

  // 1. Hook Canvas text rendering (fillText & strokeText) for live strike price badge
  function inspectCanvasText(text) {
    if (text === undefined || text === null) return;
    const s = String(text).trim();
    // Match 1 to 6 decimal places: e.g. 1.840903, 230.689, 0.96663
    if (s.length >= 4 && s.length <= 15) {
      const m = s.match(/^(\d{1,5}\.\d{1,6})$/);
      if (m) {
        const val = parseFloat(m[1]);
        if (!isNaN(val) && val > 0.0001 && val !== 1.0 && val !== 100.0) {
          const now = Date.now();
          if (now - lastPostTime > 80 || Math.abs(val - lastPriceSent) > 0.000005) {
            lastPriceSent = val;
            lastPostTime = now;
            window.postMessage({
              source: 'PO_CANVAS_STREAM',
              type: 'CANVAS_STRIKE',
              price: val
            }, '*');
          }
        }
      }
    }
  }

  const origFillText = CanvasRenderingContext2D.prototype.fillText;
  CanvasRenderingContext2D.prototype.fillText = function(text, x, y, maxWidth) {
    inspectCanvasText(text);
    return origFillText.apply(this, arguments);
  };

  const origStrokeText = CanvasRenderingContext2D.prototype.strokeText;
  CanvasRenderingContext2D.prototype.strokeText = function(text, x, y, maxWidth) {
    inspectCanvasText(text);
    return origStrokeText.apply(this, arguments);
  };

  // 2. Hook Canvas rect rendering to track every candlestick on screen
  function recordCandleRect(x, y, w, h, style) {
    if (w >= 1 && w <= 80 && h >= 1) {
      const color = classifyCandleColor(style);
      if (color) {
        const slotKey = Math.round(x / 4) * 4;
        const existing = candleMap.get(slotKey);
        const isBody = w >= 2;

        if (existing) {
          if (isBody) {
            existing.bodyTop = y;
            existing.bodyBottom = y + h;
            existing.color = color;
            existing.isBody = true;
            existing.w = w;
          }
          existing.highY = Math.min(existing.highY, y);
          existing.lowY = Math.max(existing.lowY, y + h);
          existing.time = Date.now();
        } else {
          candleMap.set(slotKey, {
            x: Math.round(x),
            bodyTop: y,
            bodyBottom: y + h,
            highY: y,
            lowY: y + h,
            w: w,
            isBody: isBody,
            color: color,
            time: Date.now()
          });
        }
      }
    }
  }

  const origFillRect = CanvasRenderingContext2D.prototype.fillRect;
  CanvasRenderingContext2D.prototype.fillRect = function(x, y, w, h) {
    recordCandleRect(x, y, w, h, this.fillStyle);
    return origFillRect.apply(this, arguments);
  };

  const origStrokeRect = CanvasRenderingContext2D.prototype.strokeRect;
  CanvasRenderingContext2D.prototype.strokeRect = function(x, y, w, h) {
    recordCandleRect(x, y, w, h, this.strokeStyle);
    return origStrokeRect.apply(this, arguments);
  };

  // Also hook rect and roundRect if charting library uses path-based rectangles
  const origRect = CanvasRenderingContext2D.prototype.rect;
  CanvasRenderingContext2D.prototype.rect = function(x, y, w, h) {
    recordCandleRect(x, y, w, h, this.fillStyle);
    return origRect.apply(this, arguments);
  };

  if (CanvasRenderingContext2D.prototype.roundRect) {
    const origRoundRect = CanvasRenderingContext2D.prototype.roundRect;
    CanvasRenderingContext2D.prototype.roundRect = function(x, y, w, h, radii) {
      recordCandleRect(x, y, w, h, this.fillStyle);
      return origRoundRect.apply(this, arguments);
    };
  }

  // Hook moveTo & lineTo for charting engines that draw candlesticks as stroked vertical lines
  let currentPathStart = null;
  const origMoveTo = CanvasRenderingContext2D.prototype.moveTo;
  CanvasRenderingContext2D.prototype.moveTo = function(x, y) {
    currentPathStart = { x, y };
    return origMoveTo.apply(this, arguments);
  };

  const origLineTo = CanvasRenderingContext2D.prototype.lineTo;
  CanvasRenderingContext2D.prototype.lineTo = function(x, y) {
    if (currentPathStart && Math.abs(currentPathStart.x - x) <= 2) {
      const topY = Math.min(currentPathStart.y, y);
      const bottomY = Math.max(currentPathStart.y, y);
      const h = bottomY - topY;
      const lw = this.lineWidth || 1;
      if (h >= 1 && lw >= 1 && lw <= 80) {
        recordCandleRect(x - (lw / 2), topY, lw, h, this.strokeStyle || this.fillStyle);
      }
    }
    currentPathStart = { x, y };
    return origLineTo.apply(this, arguments);
  };

  // Periodically evaluate and broadcast the ground-truth screen state (every 300ms)
  setInterval(() => {
    const now = Date.now();
    for (const [key, item] of candleMap.entries()) {
      if (now - item.time > 20000) {
        candleMap.delete(key);
      }
    }

    if (candleMap.size < 2) return;

    let list = Array.from(candleMap.values());
    const bodies = list.filter(c => c.isBody);
    const candidateList = bodies.length >= 2 ? bodies : list;

    const sorted = candidateList.sort((a, b) => a.x - b.x);
    if (sorted.length < 2) return;

    const activeCandle = sorted[sorted.length - 1];
    const lastCompletedCandle = sorted[sorted.length - 2];
    const prevCandle = sorted.length >= 3 ? sorted[sorted.length - 3] : lastCompletedCandle;

    let streak = 1;
    const targetColor = lastCompletedCandle.color;
    for (let i = sorted.length - 3; i >= 0; i--) {
      if (sorted[i].color === targetColor) streak++;
      else break;
    }

    // Calculate visual chart regression slope across all visible candles
    // In canvas: smaller Y = higher price (Bullish), larger Y = lower price (Bearish)
    const n = Math.min(25, sorted.length);
    const recentSlice = sorted.slice(-n);
    let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
    for (let i = 0; i < n; i++) {
      const midY = (recentSlice[i].bodyTop + recentSlice[i].bodyBottom) / 2;
      sumX += i;
      sumY += midY;
      sumXY += i * midY;
      sumXX += i * i;
    }
    const slope = (n * sumXY - sumX * sumY) / Math.max(1, n * sumXX - sumX * sumX);

    let screenTrend = 'RANGE';
    // Negative slope in canvas means Y is decreasing over time -> Price is rising (BULLISH)
    if (slope < -0.3) {
      screenTrend = 'BULLISH';
    } else if (slope > 0.3) {
      screenTrend = 'BEARISH';
    }

    let isReversing = null;
    if (prevCandle.color === 'GREEN' && lastCompletedCandle.color === 'RED') {
      isReversing = 'BEARISH_REVERSAL';
    } else if (prevCandle.color === 'RED' && lastCompletedCandle.color === 'GREEN') {
      isReversing = 'BULLISH_REVERSAL';
    }

    // Package real screen candle geometries for indicator engine
    const screenCandles = sorted.slice(-45).map(c => ({
      x: c.x,
      color: c.color,
      topY: c.bodyTop,
      bottomY: c.bodyBottom,
      highY: c.highY,
      lowY: c.lowY,
      bodyHeight: Math.max(1, c.bodyBottom - c.bodyTop)
    }));

    if (now - lastStatePostTime > 300) {
      lastStatePostTime = now;
      window.postMessage({
        source: 'PO_CANVAS_STREAM',
        type: 'REAL_SCREEN_STATE',
        state: {
          lastCompletedColor: lastCompletedCandle.color,
          prevColor: prevCandle.color,
          currentColor: activeCandle.color,
          consecutiveCount: streak,
          consecutiveColor: targetColor,
          screenTrend: screenTrend,
          slope: Number(slope.toFixed(3)),
          isReversing: isReversing,
          recentColors: sorted.slice(-15).map(c => c.color),
          realScreenCandles: screenCandles,
          totalVisible: sorted.length
        }
      }, '*');
    }
  }, 300);

  // 3. Transparent WebSocket Proxy
  try {
    const origWebSocket = window.WebSocket;
    window.WebSocket = new Proxy(origWebSocket, {
      construct(target, args) {
        const ws = Reflect.construct(target, args);

        const origSend = ws.send;
        ws.send = function(data) {
          try {
            if (typeof data === 'string') {
              const bIdx = data.indexOf('[');
              if (bIdx !== -1) {
                const parsed = JSON.parse(data.substring(bIdx));
                const cmd = parsed[0];
                const payload = parsed[1];
                if (cmd === 'changeSymbol' || cmd === 'changeAsset' || cmd === 'subscribe' || cmd === 'open') {
                  const asset = typeof payload === 'string' ? payload : (payload?.asset || payload?.symbol);
                  if (asset) {
                    window.postMessage({
                      source: 'PO_INJECTED',
                      type: 'ASSET_CHANGED',
                      asset: String(asset)
                    }, '*');
                  }
                }
              }
            }
          } catch (e) {}
          return origSend.apply(this, arguments);
        };

        // Deep recursive candle extractor for any payload format
        function extractCandlesFromPayload(data, depth = 0) {
          if (!data || depth > 3) return null;
          if (Array.isArray(data)) {
            if (data.length >= 3) {
              const first = data[0];
              if (first && typeof first === 'object') {
                if (first.open !== undefined || first.close !== undefined || first.o !== undefined || first.c !== undefined) {
                  return data;
                }
              }
              if (Array.isArray(first) && first.length >= 4 && typeof first[1] === 'number') {
                return data.map(item => ({
                  time: item[0],
                  open: item[1],
                  close: item[2],
                  high: item[3] !== undefined ? item[3] : Math.max(item[1], item[2]),
                  low: item[4] !== undefined ? item[4] : Math.min(item[1], item[2])
                }));
              }
            }
            for (const item of data) {
              if (item && typeof item === 'object') {
                const found = extractCandlesFromPayload(item, depth + 1);
                if (found) return found;
              }
            }
            return null;
          }
          if (typeof data === 'object') {
            for (const key of ['candles', 'data', 'history', 'quotes', 'bars', 'period', 'historyData']) {
              if (data[key]) {
                const found = extractCandlesFromPayload(data[key], depth + 1);
                if (found) return found;
              }
            }
          }
          return null;
        }

        ws.addEventListener('message', function(event) {
          try {
            if (typeof event.data === 'string') {
              const bIdx = event.data.indexOf('[');
              const oIdx = event.data.indexOf('{');
              const startIdx = (bIdx !== -1 && (oIdx === -1 || bIdx < oIdx)) ? bIdx : oIdx;
              if (startIdx !== -1) {
                const parsed = JSON.parse(event.data.substring(startIdx));
                const eventName = Array.isArray(parsed) ? parsed[0] : (parsed.event || parsed.type || '');
                const eventPayload = Array.isArray(parsed) ? parsed[1] : (parsed.data || parsed.payload || parsed);

                // 3A. Real-time tick stream
                if ((eventName === 'updateStream' || eventName === 'tick' || eventName === 'price') && Array.isArray(eventPayload)) {
                  const items = Array.isArray(eventPayload[0]) ? eventPayload : [eventPayload];
                  for (const item of items) {
                    if (Array.isArray(item) && item.length >= 2) {
                      const asset = String(item[0]);
                      const p = (item.length >= 3) ? (parseFloat(item[2]) || parseFloat(item[1])) : parseFloat(item[1]);
                      if (!isNaN(p) && p > 0) {
                        window.postMessage({
                          source: 'PO_INJECTED',
                          type: 'TICK',
                          asset: asset,
                          price: p
                        }, '*');
                      }
                    }
                  }
                }

                // 3B. Universal History Candle Interceptor
                const candles = extractCandlesFromPayload(eventPayload) || extractCandlesFromPayload(parsed);
                if (candles && candles.length >= 3) {
                  window.postMessage({
                    source: 'PO_INJECTED',
                    type: 'HISTORY_CANDLES',
                    payload: candles,
                    asset: eventPayload?.asset || eventPayload?.symbol || parsed?.asset || parsed?.symbol || null
                  }, '*');
                }
              }
            }
          } catch (err) {}
        });

        return ws;
      }
    });
  } catch (err) {}

  // 4. Memory Scanner for Live Chart Data in Window
  setInterval(() => {
    try {
      const candidates = [
        window.chartData,
        window.candles,
        window.App?.chart?.data,
        window.App?.deals,
        window.tradingView?.chart
      ];
      for (const cand of candidates) {
        if (Array.isArray(cand) && cand.length >= 5) {
          window.postMessage({
            source: 'PO_INJECTED',
            type: 'HISTORY_CANDLES',
            payload: cand
          }, '*');
          break;
        }
      }
    } catch (e) {}
  }, 3000);
})();
